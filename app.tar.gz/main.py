"""
IronQuest Mobile - the phone version of IronQuest, built with Flet.

All game rules live in ironquest_core.py (shared with the desktop app's logic).
This file only builds the screens:

    Home     hero card: level, XP bar, stats, weekly boss, quests
    Forge    workout generator (time, focus, equipment) with swap
    Workout  set logger: big tap targets, number keyboards, check per set,
             rest timer
    History  past workouts
    Profile  hero details, records and achievements

Phones have no hover, so tapping an exercise name (or its "i" icon) opens a
bottom sheet with the how-to guide and its source credit.

Run on the PC:   flet run mobile/main.py
"""

import asyncio
import os
import random
import sys
import time

import flet as ft

import ironquest_core as core

ACCENT = ft.Colors.DEEP_ORANGE_400
STAT_COLORS = {"STR": ft.Colors.RED_400, "END": ft.Colors.BLUE_400,
               "AGI": ft.Colors.GREEN_400, "VIT": ft.Colors.AMBER_400}
PHASE_LABELS = {"warmup": ("WARM-UP", ft.Colors.AMBER_400), "main": ("MAIN", ACCENT),
                "finisher": ("FINISHER", ft.Colors.PURPLE_300),
                "cooldown": ("COOL-DOWN", ft.Colors.TEAL_300),
                "extra": ("EXTRA", ft.Colors.BLUE_GREY_300)}
EFFORT_LABELS = {"easy": "Easy", "moderate": "Med", "hard": "Hard"}
TABS = ["home", "forge", "workout", "history", "profile"]


# ---------------------------------------------------------------------
#  Small UI helpers
# ---------------------------------------------------------------------

def card(*controls, padding=16, spacing=8):
    return ft.Card(content=ft.Container(ft.Column(list(controls), spacing=spacing),
                                        padding=padding))


def title(text, size=20):
    return ft.Text(text, size=size, weight=ft.FontWeight.BOLD)


def muted(text, size=13):
    return ft.Text(text, size=size, color=ft.Colors.ON_SURFACE_VARIANT)


def tag(text, color):
    return ft.Container(ft.Text(text, size=11, weight=ft.FontWeight.BOLD, color=color),
                        border=ft.Border.all(1, color), border_radius=6,
                        padding=ft.Padding.symmetric(horizontal=6, vertical=2))


def bar(value, color=ACCENT, height=10):
    return ft.ProgressBar(value=max(0.0, min(1.0, value)), color=color, bar_height=height,
                          border_radius=5, bgcolor=ft.Colors.with_opacity(0.15, color))


def prescription(ex, item, units):
    """'3 x 10 @ 25 lb' style text for a plan item."""
    sets = item["sets"]
    if ex["kind"] == "timed":
        amount = core.fmt_minutes(item.get("minutes") or ex["default"].get("minutes", 1))
    else:
        amount = f"{item.get('reps') or ex['default'].get('reps', 10)} reps"
    text = f"{sets} x {amount}" if sets > 1 else amount
    if float(item.get("weight_lb") or 0) > 0:
        text += f" @ {core.display_weight(item['weight_lb'], units)} {units}"
        if ex.get("per_hand"):
            text += " each"
    if item.get("rest"):
        text += f"  ·  rest {item['rest']}s"
    return text


# ---------------------------------------------------------------------
#  App
# ---------------------------------------------------------------------

class IronQuestMobile:
    def __init__(self, page: ft.Page, backend=None):
        self.page = page
        # Files in FLET_APP_STORAGE_DATA (or this folder) unless the web version
        # passes a browser-storage backend.
        self.store = core.DataStore(backend=backend)
        self.store.load()
        self.plan = None
        self.session = None
        self.tab = "home"
        self.drafts = {}                   # (item, set, field) -> text typed so far
        self.errors = {}                   # (item, set) -> validation message
        self.rest_end = None
        self.rest_total = 0
        self.forge_minutes = 45
        self.forge_focus = "Full Body"
        self.forge_equipment = None
        self.lib_back = "forge"            # where the library's back arrow returns to
        self.lib_query, self.lib_pattern, self.lib_equip = "", "all", "all"
        self.edit_id = None                # custom exercise being edited (None = new)

        page.title = "IronQuest"
        page.theme_mode = ft.ThemeMode.DARK
        page.theme = ft.Theme(color_scheme_seed=ft.Colors.DEEP_ORANGE)
        page.dark_theme = ft.Theme(color_scheme_seed=ft.Colors.DEEP_ORANGE)
        page.padding = 0
        # On the PC, show a phone-sized window.
        if not page.web and page.platform in (ft.PagePlatform.WINDOWS, ft.PagePlatform.MACOS,
                                               ft.PagePlatform.LINUX):
            page.window.width, page.window.height = 400, 820
        page.on_app_lifecycle_state_change = self._on_lifecycle

        # Rest timer banner stays pinned above the scrolling screen content.
        self.rest_text = ft.Text("", size=28, weight=ft.FontWeight.BOLD)
        self.rest_bar = bar(0, ft.Colors.TEAL_300, 8)
        self.rest_box = ft.Container(
            ft.Column([ft.Row([ft.Icon(ft.Icons.TIMER, color=ft.Colors.TEAL_300),
                               muted("Rest"), self.rest_text, ft.Container(expand=True),
                               ft.TextButton("+30s", on_click=self.add_rest),
                               ft.TextButton("Skip", on_click=self.skip_rest)]),
                       self.rest_bar], spacing=4),
            padding=12, border_radius=12, visible=False,
            margin=ft.Margin.only(left=12, right=12, top=8),
            bgcolor=ft.Colors.with_opacity(0.18, ft.Colors.TEAL_300))
        self.elapsed_text = muted("")
        self.body = ft.Column(expand=True, scroll=ft.ScrollMode.AUTO, spacing=12)
        self.root = ft.SafeArea(ft.Column([self.rest_box,
                                           ft.Container(self.body, padding=12, expand=True)],
                                          spacing=0, expand=True), expand=True)
        page.add(self.root)

        if self.store.hero is None:
            self.show_onboarding()
        else:
            self.start_main()
        if self.store.warnings:
            self.toast("\n".join(self.store.warnings))
            self.store.warnings.clear()
        page.run_task(self._ticker)

    # ----- persistence -----
    @property
    def hero(self):
        return self.store.hero

    def save(self):
        if self.hero is not None:
            self.hero["active_session"] = self.session
        if not self.store.save_all():
            self.toast(self.store.warnings[-1])
            return False
        return True

    def _on_lifecycle(self, e):
        # Phones can kill a backgrounded app at any time: save when leaving.
        if self.hero is not None:
            self.save()

    def toast(self, message):
        self.page.show_dialog(ft.SnackBar(ft.Text(message)))

    # ----- navigation -----
    def start_main(self):
        core.ensure_week(self.hero)
        self.session = core.clean_session(self.hero.get("active_session"), self.store.ex_map)
        self.forge_equipment = list(self.hero["equipment"])
        self.page.navigation_bar = ft.NavigationBar(
            selected_index=0,
            on_change=lambda e: self.go(TABS[e.control.selected_index]),
            destinations=[
                ft.NavigationBarDestination(icon=ft.Icons.HOME_OUTLINED,
                                            selected_icon=ft.Icons.HOME, label="Home"),
                ft.NavigationBarDestination(icon=ft.Icons.AUTO_AWESOME_OUTLINED,
                                            selected_icon=ft.Icons.AUTO_AWESOME, label="Forge"),
                ft.NavigationBarDestination(icon=ft.Icons.FITNESS_CENTER, label="Workout"),
                ft.NavigationBarDestination(icon=ft.Icons.HISTORY, label="History"),
                ft.NavigationBarDestination(icon=ft.Icons.PERSON_OUTLINE,
                                            selected_icon=ft.Icons.PERSON, label="Profile"),
            ])
        self.save()
        self.go("home")

    def go(self, tab):
        if tab != self.tab:
            self.page.run_task(self.body.scroll_to, offset=0)
        self.tab = tab
        self.rest_box.visible = self.rest_end is not None
        if self.page.navigation_bar and tab in TABS:   # library/editor keep the current tab lit
            self.page.navigation_bar.selected_index = TABS.index(tab)
        builder = {"home": self.build_home, "forge": self.build_forge,
                   "workout": self.build_workout, "history": self.build_history,
                   "profile": self.build_profile, "library": self.build_library,
                   "editor": self.build_editor}[tab]
        self.body.controls = builder()
        self.page.update()

    def refresh(self):
        self.go(self.tab)

    # ----- how-to guide bottom sheet -----
    def show_guide(self, ex, manage=False):
        """How-to sheet. manage=True (from the Library) adds details and Edit/Delete."""
        text, source = core.guide_text(ex)
        muscles = ", ".join(ex["primary"])
        if ex["secondary"]:
            muscles += f"  (+ {', '.join(ex['secondary'])})"
        equipment = ", ".join(ex["equipment"]) or "bodyweight"
        name_row = [ft.Text(ex["name"], size=20, weight=ft.FontWeight.BOLD, expand=True)]
        if ex.get("custom"):
            name_row.append(tag("CUSTOM", ft.Colors.AMBER_400))
        content = [ft.Row(name_row), muted(f"Works: {muscles}"), muted(f"Equipment: {equipment}"),
                   ft.Divider(), ft.Text(text, size=15, selectable=True)]
        if source:
            content.append(ft.Text(f"Source: {source}", size=12, italic=True,
                                   color=ft.Colors.ON_SURFACE_VARIANT, selectable=True))
        if manage:
            content += [ft.Divider()] + [
                ft.Row([muted(k), ft.Text(v, weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.RIGHT,
                                          expand=True)])
                for k, v in self.exercise_facts(ex)]
            if ex.get("custom"):
                content.append(ft.Row([
                    ft.OutlinedButton("Edit", icon=ft.Icons.EDIT,
                                      on_click=lambda e: (self.page.pop_dialog(), self.open_editor(ex))),
                    ft.TextButton("Delete", icon=ft.Icons.DELETE_OUTLINE,
                                  style=ft.ButtonStyle(color=ft.Colors.RED_300),
                                  on_click=lambda e: (self.page.pop_dialog(), self.delete_custom(ex))),
                ]))
        content.append(ft.TextButton("Close", on_click=lambda e: self.page.pop_dialog()))
        sheet = ft.BottomSheet(
            ft.Container(ft.Column(content, tight=True, scroll=ft.ScrollMode.AUTO, spacing=8),
                         padding=20),
            show_drag_handle=True, scrollable=True)
        self.page.show_dialog(sheet)

    def exercise_title(self, ex, size=17):
        """Exercise name you can tap (plus an 'i' icon) to open its guide."""
        return ft.Row([
            ft.Container(ft.Text(ex["name"], size=size, weight=ft.FontWeight.BOLD),
                         on_click=lambda e, ex=ex: self.show_guide(ex), expand=True,
                         padding=ft.Padding.symmetric(vertical=6)),
            ft.IconButton(ft.Icons.INFO_OUTLINE, tooltip="How to do it",
                          on_click=lambda e, ex=ex: self.show_guide(ex)),
        ], spacing=0)

    # =================================================================
    #  ONBOARDING (first launch on a new phone)
    # =================================================================
    def show_onboarding(self):
        self.page.navigation_bar = None
        name = ft.TextField(label="Hero name", max_length=core.NAME_MAX)
        units = ft.SegmentedButton(segments=[ft.Segment("lb", label="lb"),
                                             ft.Segment("kg", label="kg")], selected=["lb"])
        bw = ft.TextField(label="Bodyweight", keyboard_type=ft.KeyboardType.NUMBER)
        goal = ft.Dropdown(label="Main goal", value="General", options=[
            ft.DropdownOption(g) for g in core.GOALS], expand=True)
        days = ft.Slider(min=core.DAYS_RANGE[0], max=core.DAYS_RANGE[1],
                         divisions=core.DAYS_RANGE[1] - core.DAYS_RANGE[0], value=3,
                         label="{value} days / week")
        equip = set()
        chips = [ft.Chip(label=e, selected=False,
                         on_select=lambda ev, e=e: (equip.add(e) if ev.control.selected
                                                    else equip.discard(e)))
                 for e in core.EQUIPMENT]
        error = ft.Text("", color=ft.Colors.RED_300)

        def create(e):
            try:
                hero_name = core.validate_name(name.value, core.NAME_MAX, "Hero name")
                u = units.selected[0] if units.selected else "lb"
                lo, hi = core.bodyweight_range(u)
                weight = core.parse_float(bw.value, lo, hi, f"Bodyweight ({u})")
            except core.ValidationError as err:
                error.value = str(err)
                self.page.update()
                return
            self.store.hero = core.create_hero(hero_name, core.to_lb(weight, u), u,
                                               sorted(equip), goal.value, int(days.value), {})
            self.start_main()
            self.toast(f"{hero_name} has entered the realm! Head to the Forge.")

        self.body.controls = [
            title("Create your hero", 26),
            muted("IronQuest turns real training into XP, levels and boss fights."),
            card(name, ft.Row([bw, units], vertical_alignment=ft.CrossAxisAlignment.CENTER),
                 goal, muted("Training days per week"), days,
                 muted("Equipment you have (none = bodyweight only)"),
                 ft.Row(chips, wrap=True, spacing=6, run_spacing=6)),
            error,
            ft.FilledButton("Begin the quest", icon=ft.Icons.PLAY_ARROW, on_click=create,
                            height=52),
        ]
        bw.expand = True
        self.page.update()

    # =================================================================
    #  HOME
    # =================================================================
    def build_home(self):
        hero = self.hero
        core.ensure_week(hero)
        level, into, need = core.level_info(hero["total_xp"])
        cls, desc, _key = core.hero_class(hero)
        pts = core.stat_points(hero)
        streak = core.current_streak(self.store.workouts)

        stat_boxes = [ft.Container(
            ft.Column([ft.Text(s, size=12, color=STAT_COLORS[s], weight=ft.FontWeight.BOLD),
                       ft.Text(str(pts[s]), size=22, weight=ft.FontWeight.BOLD)],
                      horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=0),
            expand=True, padding=8, border_radius=10,
            bgcolor=ft.Colors.with_opacity(0.12, STAT_COLORS[s]),
            tooltip=core.STAT_NAMES[s]) for s in core.STATS]

        hero_card = card(
            ft.Row([ft.Column([title(hero["name"], 24), muted(f"{cls} · {desc}")],
                              spacing=2, expand=True),
                    ft.Container(ft.Text(f"LV {level}", size=20, weight=ft.FontWeight.BOLD),
                                 bgcolor=ft.Colors.with_opacity(0.2, ACCENT),
                                 border_radius=12, padding=10)]),
            bar(into / need),
            muted(f"{into} / {need} XP to level {level + 1}   ·   {hero['total_xp']} total XP"),
            ft.Row(stat_boxes, spacing=6),
            muted(f"🔥 Streak: {streak} session{'s' if streak != 1 else ''}"),
        )

        boss = hero["boss"]
        boss_card = card(
            ft.Row([ft.Icon(ft.Icons.WHATSHOT, color=ft.Colors.RED_400),
                    title("Weekly boss", 16)]),
            ft.Text(boss["name"], size=18, weight=ft.FontWeight.BOLD),
            muted(boss["flavor"]),
            bar(boss["hp"] / boss["max_hp"], ft.Colors.RED_400, 14),
            ft.Text("DEFEATED! +100 XP" if boss["defeated"]
                    else f"{boss['hp']} / {boss['max_hp']} HP  ·  every workout XP deals damage",
                    size=13, color=ft.Colors.GREEN_400 if boss["defeated"] else None),
        )

        wk = core.week_workouts(self.store.workouts)
        quest_rows = []
        for q in hero["quests"]["list"]:
            prog = min(q["n"], core.quest_progress(q, wk))
            quest_rows.append(ft.Column([
                ft.Row([ft.Icon(ft.Icons.CHECK_CIRCLE if q["done"] else ft.Icons.RADIO_BUTTON_UNCHECKED,
                                color=ft.Colors.GREEN_400 if q["done"] else None, size=20),
                        ft.Text(core.quest_text(q), expand=True),
                        muted(f"+{q['reward']}")]),
                bar(prog / q["n"], ft.Colors.GREEN_400, 6),
            ], spacing=4))
        quest_card = card(title("This week's quests", 16), *quest_rows, spacing=12)

        fatigue = core.fatigue_now(hero)
        tired = sorted(((v, m) for m, v in fatigue.items() if v >= 20), reverse=True)[:3]
        recovery = ", ".join(f"{m} {round(v)}%" for v, m in tired) or "Fully recovered"

        controls = [hero_card]
        if self.session:
            done = sum(1 for it in self.session["items"] for s in it["sets"] if s.get("done"))
            total = sum(len(it["sets"]) for it in self.session["items"])
            controls.append(ft.FilledButton(
                f"Resume {self.session['name']} ({done}/{total} sets)",
                icon=ft.Icons.PLAY_ARROW, height=52, on_click=lambda e: self.go("workout")))
        else:
            controls.append(ft.FilledButton("Forge a workout", icon=ft.Icons.AUTO_AWESOME,
                                            height=52, on_click=lambda e: self.go("forge")))
        controls += [boss_card, quest_card, card(title("Recovery", 16), muted(recovery))]
        return controls

    # =================================================================
    #  FORGE (workout generator)
    # =================================================================
    def build_forge(self):
        minutes_text = ft.Text(f"{self.forge_minutes} min", weight=ft.FontWeight.BOLD)

        def set_minutes(e):
            self.forge_minutes = int(e.control.value)
            minutes_text.value = f"{self.forge_minutes} min"
            minutes_text.update()

        def set_focus(e):
            self.forge_focus = e.control.value

        def toggle_equipment(e, name):
            if e.control.selected:
                self.forge_equipment.append(name)
            else:
                self.forge_equipment.remove(name)

        options = card(
            ft.Row([title("Forge a workout"),
                    ft.TextButton("Library", icon=ft.Icons.MENU_BOOK, on_click=self.open_library)],
                   alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            ft.Row([muted("Length"), minutes_text], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            ft.Slider(min=15, max=120, divisions=21, value=self.forge_minutes,
                      label="{value} min", on_change=set_minutes),
            ft.Dropdown(label="Focus", value=self.forge_focus, expand=True,
                        options=[ft.DropdownOption(f) for f in core.FOCUSES], on_select=set_focus),
            muted("Equipment today"),
            ft.Row([ft.Chip(label=e, selected=e in self.forge_equipment,
                            on_select=lambda ev, e=e: toggle_equipment(ev, e))
                    for e in core.EQUIPMENT], wrap=True, spacing=6, run_spacing=6),
            ft.FilledButton("Generate", icon=ft.Icons.AUTO_AWESOME, height=52,
                            on_click=self.generate),
        )
        controls = [options]
        if self.plan:
            controls += self.plan_controls()
        return controls

    def generate(self, e=None):
        try:
            self.plan = core.generate_workout(self.store.exercises, self.hero, self.store.workouts,
                                              self.forge_minutes, self.forge_equipment,
                                              self.forge_focus)
        except core.ValidationError as err:
            self.toast(str(err))
            return
        self.refresh()

    def swap(self, index):
        if not core.swap_item(self.plan, index, self.store.exercises, self.hero,
                              self.store.workouts):
            self.toast("No other exercise fits that slot with this equipment.")
            return
        self.refresh()

    def plan_controls(self):
        plan, ex_map, units = self.plan, self.store.ex_map, self.hero["units"]
        out = [ft.Row([title(plan["name"]), muted(f"~{plan['est_min']} min")],
                      alignment=ft.MainAxisAlignment.SPACE_BETWEEN)]
        for note in plan["notes"]:
            out.append(ft.Text(f"⚠ {note}", color=ft.Colors.AMBER_300, size=13))
        for i, item in enumerate(plan["items"]):
            ex = ex_map[item["ex_id"]]
            label, color = PHASE_LABELS.get(item["phase"], ("", ACCENT))
            out.append(card(
                ft.Row([tag(label, color), ft.Container(expand=True),
                        ft.IconButton(ft.Icons.SWAP_HORIZ, tooltip="Swap exercise",
                                      on_click=lambda e, i=i: self.swap(i))]),
                self.exercise_title(ex),
                muted(prescription(ex, item, units), 14),
                padding=12, spacing=2))
        out.append(ft.FilledButton("Start workout", icon=ft.Icons.PLAY_ARROW, height=56,
                                   on_click=self.start_workout))
        return out

    def start_workout(self, e=None):
        if self.session:
            def replace(ev):
                self.page.pop_dialog()
                self._begin_session()
            self.page.show_dialog(ft.AlertDialog(
                title="Replace current workout?",
                content=ft.Text("You have a workout in progress. Its unfinished sets will be lost."),
                actions=[ft.TextButton("Cancel", on_click=lambda ev: self.page.pop_dialog()),
                         ft.FilledButton("Replace", on_click=replace)]))
            return
        self._begin_session()

    def _begin_session(self):
        self.session = core.session_from_plan(self.plan, self.store.ex_map)
        self.plan, self.drafts, self.errors, self.rest_end = None, {}, {}, None
        self.save()
        self.go("workout")

    # =================================================================
    #  WORKOUT (set logger + rest timer)
    # =================================================================
    def build_workout(self):
        sess = self.session
        if not sess:
            return [card(title("No workout in progress"),
                         muted("Forge a workout to start logging sets."),
                         ft.FilledButton("Go to the Forge", icon=ft.Icons.AUTO_AWESOME,
                                         height=52, on_click=lambda e: self.go("forge")))]
        units = self.hero["units"]
        done = sum(1 for it in sess["items"] for s in it["sets"] if s.get("done"))
        total = sum(len(it["sets"]) for it in sess["items"])

        self.elapsed_text = muted("")
        self._update_clock()

        controls = [
            ft.Row([ft.Column([title(sess["name"]), self.elapsed_text], spacing=0, expand=True),
                    ft.Text(f"{done}/{total}", size=20, weight=ft.FontWeight.BOLD)]),
            bar(done / total if total else 0),
        ]
        for i, it in enumerate(sess["items"]):
            ex = self.store.ex_map[it["ex_id"]]
            label, color = PHASE_LABELS.get(it.get("phase"), ("", ACCENT))
            rows = [ft.Row([tag(label, color),
                            muted(f"rest {it['rest']}s" if it.get("rest") else "")]),
                    self.exercise_title(ex)]
            for j, s in enumerate(it["sets"]):
                rows.append(self.set_row(i, j, ex, s, units))
                if (i, j) in self.errors:
                    rows.append(ft.Text("⚠ " + self.errors[(i, j)], color=ft.Colors.RED_300,
                                        size=13))
            rows.append(ft.TextButton("Add set", icon=ft.Icons.ADD,
                                      on_click=lambda e, i=i: self.add_set(i)))
            controls.append(card(*rows, padding=12, spacing=6))
        controls.append(ft.FilledButton("Finish workout", icon=ft.Icons.FLAG, height=56,
                                        on_click=self.finish))
        controls.append(ft.TextButton("Discard workout", icon=ft.Icons.DELETE_OUTLINE,
                                      on_click=self.discard))
        return controls

    def set_row(self, i, j, ex, s, units):
        done = bool(s.get("done"))

        def field(key, label, initial, width=None):
            text = self.drafts.get((i, j, key), initial)
            tf = ft.TextField(value=text, label=label, keyboard_type=ft.KeyboardType.NUMBER,
                              dense=False, text_size=18, disabled=done, expand=width is None,
                              width=width, text_align=ft.TextAlign.CENTER,
                              on_change=lambda e: self.drafts.__setitem__((i, j, key),
                                                                          e.control.value))
            return tf

        cells = [ft.Container(ft.Text(str(j + 1), size=16, weight=ft.FontWeight.BOLD),
                              width=24, alignment=ft.Alignment.CENTER)]
        if ex["kind"] == "reps":
            cells.append(field("reps", "Reps", str(s.get("reps") or "")))
            if core.uses_weight(ex) or float(s.get("weight_lb") or 0) > 0:
                w = float(s.get("weight_lb") or 0)
                each = " each" if ex.get("per_hand") else ""
                cells.append(field("weight", f"{units}{each}",
                                   core.display_weight(w, units) if w > 0 else ""))
        else:
            cells.append(field("minutes", "Minutes", core.fmt_num(s.get("minutes") or 1), 96))
            cells.append(ft.Dropdown(
                value=s.get("effort", "moderate"), expand=True, disabled=done, dense=True,
                options=[ft.DropdownOption(key=x, text=EFFORT_LABELS[x]) for x in core.EFFORTS],
                on_select=lambda e: s.__setitem__("effort", e.control.value)))
        cells.append(ft.IconButton(
            ft.Icons.CHECK_CIRCLE if done else ft.Icons.CHECK_CIRCLE_OUTLINE,
            icon_size=40, icon_color=ft.Colors.GREEN_400 if done else None,
            tooltip="Undo" if done else "Done",
            on_click=lambda e: self.toggle_set(i, j)))
        return ft.Row(cells, spacing=6, vertical_alignment=ft.CrossAxisAlignment.CENTER)

    def read_set(self, i, j):
        """Validate what was typed for one set (same rules as the desktop app)."""
        it = self.session["items"][i]
        s, ex, units = it["sets"][j], self.store.ex_map[it["ex_id"]], self.hero["units"]
        values = {}
        if ex["kind"] == "reps":
            reps = self.drafts.get((i, j, "reps"), str(s.get("reps") or ""))
            values["reps"] = core.parse_int(reps, *core.REPS_RANGE, "Reps")
            w = float(s.get("weight_lb") or 0)
            raw = self.drafts.get((i, j, "weight"), core.display_weight(w, units) if w > 0 else "")
            lo, hi = core.weight_range(units)
            values["weight_lb"] = core.to_lb(core.parse_float(raw.strip() or "0", lo, hi,
                                                              f"Weight ({units})"), units)
        else:
            raw = self.drafts.get((i, j, "minutes"), core.fmt_num(s.get("minutes") or 1))
            values["minutes"] = core.parse_float(raw, *core.MINUTES_RANGE, "Minutes")
        return values

    def toggle_set(self, i, j):
        it = self.session["items"][i]
        s = it["sets"][j]
        if s.get("done"):
            s["done"] = False
        else:
            try:
                s.update(self.read_set(i, j))
            except core.ValidationError as err:
                self.errors[(i, j)] = str(err)
                self.refresh()
                return
            s["done"] = True
            self.errors.pop((i, j), None)
            for key in ("reps", "weight", "minutes"):
                self.drafts.pop((i, j, key), None)
            if it.get("rest"):
                self.start_rest(it["rest"])
        self.save()
        self.refresh()

    def add_set(self, i):
        it = self.session["items"][i]
        ex = self.store.ex_map[it["ex_id"]]
        last = it["sets"][-1] if it["sets"] else {}
        it["sets"].append(core.new_set(ex, last.get("reps"), last.get("weight_lb", 0.0),
                                       last.get("minutes")))
        self.save()
        self.refresh()

    # ----- rest timer -----
    def start_rest(self, seconds):
        self.rest_total = seconds
        self.rest_end = time.monotonic() + seconds

    def add_rest(self, e=None):
        if self.rest_end:
            self.rest_end += 30
            self.rest_total += 30
            self._update_clock()
            self.page.update()

    def skip_rest(self, e=None):
        self.rest_end = None
        self._update_clock()
        self.page.update()

    def _update_clock(self):
        """Refresh the rest countdown banner and the workout's elapsed time."""
        if not self.session and not self.rest_end:
            return False
        if self.session:
            started = core.parse_iso(self.session.get("started"), core.now())
            mins = int((core.now() - started).total_seconds() // 60)
            self.elapsed_text.value = f"{self.session['focus']} · {mins} min elapsed"
        if self.rest_end:
            left = self.rest_end - time.monotonic()
            if left <= 0:
                self.rest_end = None
                self.toast("Rest over - next set!")
            else:
                secs = int(left + 0.999)
                self.rest_text.value = f"{secs // 60}:{secs % 60:02d}"
                self.rest_bar.value = left / self.rest_total if self.rest_total else 0
        self.rest_box.visible = self.rest_end is not None
        return True

    async def _ticker(self):
        while True:
            await asyncio.sleep(1)
            try:
                if self._update_clock():
                    self.page.update()
            except Exception:       # never let the timer crash the app
                pass

    # ----- finish / discard -----
    def finish(self, e=None):
        try:
            summary = core.finish_workout(self.hero, self.store.workouts, self.store.ex_map,
                                          self.session)
        except core.ValidationError as err:
            self.toast(str(err))
            return
        self.session, self.drafts, self.errors, self.rest_end = None, {}, {}, None
        self.save()
        self.show_summary(summary)
        self.go("home")

    def show_summary(self, r):
        lines = [ft.Text(f"+{r['total_gained']} XP", size=32, weight=ft.FontWeight.BOLD,
                         color=ACCENT),
                 muted(f"{r['sets']} sets · {r['duration']} min · streak x{r['streak_mult']:.2f}")]
        for name, n_sets, xp in r["lines"]:
            lines.append(ft.Row([ft.Text(name, expand=True), muted(f"{n_sets} sets"),
                                 ft.Text(f"{xp} XP")]))
        extras = []
        if r["level_after"] > r["level_before"]:
            extras.append(f"⬆ Level up! You are now level {r['level_after']}.")
        if r["class_after"] != r["class_before"]:
            extras.append(f"New class: {r['class_after']}")
        if r["prs"]:
            extras.append("🏆 New records: " + ", ".join(r["prs"]))
        if r["boss_damage"]:
            extras.append(f"⚔ Boss took {r['boss_damage']} damage")
        if r["boss_defeated"]:
            extras.append(f"💀 Boss defeated! +{r['boss_bonus']} XP")
        for q in r["quests_done"]:
            extras.append(f"✔ Quest complete: {q}")
        for a in r["achievements"]:
            extras.append(f"🎖 Achievement: {a}")
        if r["tired_sets"]:
            extras.append(f"{r['tired_sets']} sets on tired muscles earned less XP")
        lines += [ft.Divider()] + [ft.Text(x) for x in extras]
        self.page.show_dialog(ft.AlertDialog(
            title="Quest complete!",
            content=ft.Column(lines, tight=True, scroll=ft.ScrollMode.AUTO),
            actions=[ft.FilledButton("Nice", on_click=lambda e: self.page.pop_dialog())]))

    def discard(self, e=None):
        def really(ev):
            self.page.pop_dialog()
            self.session, self.drafts, self.errors, self.rest_end = None, {}, {}, None
            self.save()
            self.go("home")
        self.page.show_dialog(ft.AlertDialog(
            title="Discard this workout?",
            content=ft.Text("Logged sets in this session will not earn XP."),
            actions=[ft.TextButton("Keep going", on_click=lambda ev: self.page.pop_dialog()),
                     ft.FilledButton("Discard", on_click=really)]))

    # =================================================================
    #  EXERCISE LIBRARY (browse, add, edit, delete custom exercises)
    # =================================================================
    def open_library(self, e=None):
        if self.tab not in ("library", "editor"):
            self.lib_back = self.tab
        self.go("library")

    def exercise_facts(self, ex):
        """Detail rows shown in the library sheet (same facts as the desktop details panel)."""
        units, d = self.hero["units"], ex["default"]
        amount = (f"{d['sets']} x {d['reps']} reps" if ex["kind"] == "reps"
                  else f"{d['sets']} x {core.fmt_minutes(d['minutes'])}")
        rec = self.hero["records"].get(ex["id"])
        times = sum(1 for w in self.store.workouts for e in w["exercises"]
                    if e.get("ex_id") == ex["id"])
        rows = [("Pattern", ex["pattern"].title()),
                ("Category", f"{ex['category'].title()} (XP x{core.TYPE_MULT[ex['category']]})"),
                ("Trains", core.STAT_NAMES[ex["stat"]]),
                ("Difficulty", core.TRAINING_LEVELS[ex["difficulty"]]),
                ("Logged as", ("reps x weight" + (" (per hand)" if ex.get("per_hand") else ""))
                 if ex["kind"] == "reps" else "minutes x effort"),
                ("Default", amount),
                ("Times done", str(times)),
                ("Your record", core.record_text(rec, units) if rec else "-")]
        if core.uses_weight(ex):
            load = core.suggest_weight(ex, self.hero, self.store.workouts)
            rows.append(("Starting load", f"{core.display_weight(load, units)} {units}"))
        return rows

    def build_library(self):
        self.lib_list = ft.Column(spacing=4)
        self.lib_count = muted("", 12)
        search = ft.TextField(value=self.lib_query, hint_text="Search exercises or muscles",
                              prefix_icon=ft.Icons.SEARCH, dense=True, expand=True,
                              on_change=lambda e: self._lib_filter(query=e.control.value))
        pattern = ft.Dropdown(
            label="Pattern", value=self.lib_pattern, expand=True, dense=True,
            options=[ft.DropdownOption(key="all", text="All")]
            + [ft.DropdownOption(key=p, text=p.title()) for p in core.PATTERNS],
            on_select=lambda e: self._lib_filter(pattern=e.control.value))
        equipment = ft.Dropdown(
            label="Equipment", value=self.lib_equip, expand=True, dense=True,
            options=[ft.DropdownOption(key="all", text="All"),
                     ft.DropdownOption(key="mine", text="My equipment"),
                     ft.DropdownOption(key="bodyweight", text="Bodyweight")]
            + [ft.DropdownOption(key=x, text=x.title()) for x in core.EQUIPMENT],
            on_select=lambda e: self._lib_filter(equip=e.control.value))
        self._fill_library()
        return [
            ft.Row([ft.IconButton(ft.Icons.ARROW_BACK, tooltip="Back",
                                  on_click=lambda e: self.go(self.lib_back)),
                    title("Exercise library")], spacing=0),
            muted("Every move the Forge knows. Tap one for its guide; add your own, too."),
            ft.FilledButton("Add custom exercise", icon=ft.Icons.ADD, height=48,
                            on_click=lambda e: self.open_editor(None)),
            ft.Row([search]), ft.Row([pattern, equipment]), self.lib_count, self.lib_list,
        ]

    def _lib_filter(self, query=None, pattern=None, equip=None):
        # Only the list is rebuilt, so the search box keeps focus while typing.
        if query is not None:
            self.lib_query = query
        if pattern is not None:
            self.lib_pattern = pattern
        if equip is not None:
            self.lib_equip = equip
        self._fill_library()
        self.page.update()

    def _fill_library(self):
        rows = core.filter_library(self.store.exercises, self.lib_query, self.lib_pattern,
                                   self.lib_equip, self.hero["equipment"])
        n_custom = sum(1 for e in self.store.exercises if e.get("custom"))
        self.lib_count.value = (f"{len(rows)} of {len(self.store.exercises)} exercises"
                                + (f"  ·  ★ = your custom ({n_custom})" if n_custom else ""))
        self.lib_list.controls = [ft.Card(ft.ListTile(
            leading=ft.Icon(ft.Icons.STAR if ex.get("custom") else ft.Icons.FITNESS_CENTER,
                            color=ft.Colors.AMBER_400 if ex.get("custom") else None),
            title=ft.Text(ex["name"], weight=ft.FontWeight.BOLD),
            subtitle=ft.Text(f"{ex['pattern'].title()} · "
                             f"{', '.join(ex['equipment']) or 'bodyweight'} · "
                             f"{', '.join(ex['primary'])}", size=12),
            trailing=ft.Text("●" * ex["difficulty"], color=ACCENT),
            on_click=lambda e, ex=ex: self.show_guide(ex, manage=True)))
            for ex in rows] or [muted("No exercises match these filters.")]

    def delete_custom(self, ex):
        try:
            core.check_not_in_session(ex, self.session)
        except core.ValidationError as err:
            self.toast(str(err))
            return

        def really(ev):
            self.page.pop_dialog()
            try:
                self.plan = core.delete_custom_exercise(self.store.exercises, ex["id"],
                                                        self.session, self.plan)
            except core.ValidationError as err:
                self.toast(str(err))
                return
            self.save()
            self.go("library")
            self.toast(f"Deleted {ex['name']}.")

        self.page.show_dialog(ft.AlertDialog(
            title="Delete exercise?",
            content=ft.Text(f"Delete '{ex['name']}' from your library? "
                            "Past workouts keep their history."),
            actions=[ft.TextButton("Cancel", on_click=lambda ev: self.page.pop_dialog()),
                     ft.FilledButton("Delete", on_click=really)]))

    def open_editor(self, ex):
        if ex is not None:
            try:
                core.check_not_in_session(ex, self.session)
            except core.ValidationError as err:
                self.toast(str(err))
                return
        self.edit_id = ex["id"] if ex else None
        self.go("editor")

    def build_editor(self):
        ex = self.store.ex_map.get(self.edit_id)
        d = ex["default"] if ex else {"sets": 3, "reps": 10}
        kind = ex["kind"] if ex else "reps"
        self.ed_equip = set(ex["equipment"]) if ex else set()

        def dropdown(label, values, value, blank=None):
            opts = ([ft.DropdownOption(key="none", text=blank)] if blank else []) + [
                ft.DropdownOption(key=v, text=v.title()) for v in values]
            return ft.Dropdown(label=label, value=value, options=opts, expand=True, dense=True)

        def segmented(values, value, labels=None):
            return ft.SegmentedButton(
                segments=[ft.Segment(str(v), label=(labels or {}).get(v, str(v))) for v in values],
                selected=[str(value)], show_selected_icon=False, expand=True)

        def amount_hint(k):
            return ("Default minutes", "0.25-180") if k == "timed" else ("Default reps", "1-100")

        def kind_changed(e):
            label, hint = amount_hint(f["kind"].selected[0])
            f["amount"].label, f["amount"].helper = label, hint
            f["amount"].update()

        def toggle_equipment(e, name):
            (self.ed_equip.add if e.control.selected else self.ed_equip.discard)(name)

        f = self.ed = {}
        f["name"] = ft.TextField(label="Name", value=ex["name"] if ex else "",
                                 hint_text="e.g. Sandbag Clean", max_length=core.EXERCISE_NAME_MAX)
        f["description"] = ft.TextField(
            label="How to do it (optional)", value=ex.get("how_to", "") if ex else "",
            multiline=True, min_lines=3, max_lines=8, max_length=core.DESC_MAX,
            helper="Shown when you tap the exercise", error_max_lines=2)
        f["pattern"] = dropdown("Pattern", core.PATTERNS, ex["pattern"] if ex else "push")
        f["category"] = dropdown("Category", core.CATEGORIES, ex["category"] if ex else "compound")
        f["primary"] = dropdown("Primary muscle", core.MUSCLES, ex["primary"][0] if ex else "chest")
        f["secondary"] = dropdown("Secondary", core.MUSCLES,
                                  (ex["secondary"] or ["none"])[0] if ex else "none", blank="None")
        f["kind"] = ft.SegmentedButton(
            segments=[ft.Segment("reps", label="Reps x weight"),
                      ft.Segment("timed", label="Minutes x effort")],
            selected=[kind], show_selected_icon=False, on_change=kind_changed, expand=True)
        label, hint = amount_hint(kind)
        f["sets"] = ft.TextField(label="Default sets", value=str(d["sets"]), helper="1-10",
                                 keyboard_type=ft.KeyboardType.NUMBER, expand=True)
        f["amount"] = ft.TextField(label=label, helper=hint, keyboard_type=ft.KeyboardType.NUMBER,
                                   value=core.fmt_num(d.get("minutes" if kind == "timed" else "reps", 10)),
                                   expand=True)
        f["difficulty"] = segmented([1, 2, 3], ex["difficulty"] if ex else 1,
                                    {1: "Beginner", 2: "Medium", 3: "Advanced"})
        f["stat"] = segmented(core.STATS, ex["stat"] if ex else "STR")
        f["per_hand"] = ft.Switch(label="Weight is per hand (two dumbbells)",
                                  value=bool(ex.get("per_hand")) if ex else False)
        self.ed_msg = ft.Text("", color=ft.Colors.RED_300)
        chips = [ft.Chip(label=x, selected=x in self.ed_equip,
                         on_select=lambda ev, x=x: toggle_equipment(ev, x)) for x in core.EQUIPMENT]
        return [
            ft.Row([ft.IconButton(ft.Icons.ARROW_BACK, tooltip="Cancel",
                                  on_click=lambda e: self.go("library")),
                    title("Edit exercise" if ex else "New custom exercise")], spacing=0),
            card(f["name"], f["description"]),
            card(muted("Movement"), ft.Row([f["pattern"], f["category"]]),
                 ft.Row([f["primary"], f["secondary"]]),
                 muted("Logged as"), ft.Row([f["kind"]]), ft.Row([f["sets"], f["amount"]])),
            card(muted("Difficulty"), ft.Row([f["difficulty"]]),
                 muted("Trains stat"), ft.Row([f["stat"]]),
                 muted("Equipment (none = bodyweight)"),
                 ft.Row(chips, wrap=True, spacing=6, run_spacing=6), f["per_hand"]),
            self.ed_msg,
            ft.FilledButton("Save changes" if ex else "Add to library", icon=ft.Icons.CHECK,
                            height=52, on_click=self.save_editor),
        ]

    def save_editor(self, e=None):
        f = self.ed
        form = {"name": f["name"].value, "description": f["description"].value,
                "pattern": f["pattern"].value, "category": f["category"].value,
                "primary": f["primary"].value, "secondary": f["secondary"].value,
                "kind": f["kind"].selected[0], "sets": f["sets"].value,
                "amount": f["amount"].value, "difficulty": int(f["difficulty"].selected[0]),
                "stat": f["stat"].selected[0], "equipment": sorted(self.ed_equip),
                "per_hand": f["per_hand"].value}
        ex, errors = core.custom_exercise(self.store.exercises, form, self.edit_id)
        for key in ("name", "description", "sets", "amount"):
            f[key].error = errors.get(key)
        for key in ("pattern", "category", "primary", "secondary"):
            f[key].error_text = errors.get(key)
        other = [errors[k] for k in ("kind", "difficulty", "stat") if k in errors]
        self.ed_msg.value = "⚠ " + " ".join(other) if other else ""
        if errors:
            self.page.update()
            self.toast("Please fix the highlighted fields.")
            return
        editing = self.edit_id is not None
        core.save_custom_exercise(self.store.exercises, ex)
        if editing and self.plan and any(i["ex_id"] == ex["id"] for i in self.plan["items"]):
            self.plan = None    # its prescription may no longer fit; forge a fresh plan
        self.save()
        self.lib_query, self.lib_pattern, self.lib_equip = ex["name"], "all", "all"
        self.go("library")
        self.toast(f"Saved {ex['name']}." if editing else
                   f"Added {ex['name']}. The Forge can now use it in workouts.")

    # =================================================================
    #  HISTORY & PROFILE (simple first versions)
    # =================================================================
    def build_history(self):
        ws = list(reversed(self.store.workouts))
        if not ws:
            return [card(title("History"), muted("No workouts yet. Your log will appear here."))]
        out = [title("History")]
        for w in ws:
            when = core.parse_iso(w["date"])
            names = ", ".join(e["name"] for e in w["exercises"][:4])
            if len(w["exercises"]) > 4:
                names += f" +{len(w['exercises']) - 4} more"
            prs = f"  ·  🏆 {len(w['prs'])} PR" if w["prs"] else ""
            out.append(card(
                ft.Row([ft.Text(w["name"], size=16, weight=ft.FontWeight.BOLD, expand=True),
                        ft.Text(f"+{w['xp']} XP", color=ACCENT, weight=ft.FontWeight.BOLD)]),
                muted(f"{core.fmt_date(when)} · {w['duration_min']} min · "
                      f"{w['sets_done']} sets{prs}"),
                muted(names, 12), padding=12, spacing=2))
        return out

    def build_profile(self):
        hero, units = self.hero, self.hero["units"]
        level = core.level_info(hero["total_xp"])[0]
        totals = core.lifetime_totals(self.store.workouts)
        info = card(
            title(hero["name"], 22),
            muted(f"Level {level} {core.hero_class(hero)[0]} · "
                  f"{core.TRAINING_LEVELS[hero['training_level']]}"),
            muted(f"Bodyweight {core.display_weight(hero['bodyweight_lb'], units)} {units} · "
                  f"Goal {hero['goal']} · {hero['days_per_week']} days/week"),
            muted("Equipment: " + (", ".join(hero["equipment"]) or "bodyweight only")),
            muted(f"{totals['workouts']} workouts · "
                  f"{core.display_weight(totals['volume_lb'], units)} {units} lifted · "
                  f"{round(totals['cardio_min'])} cardio min · "
                  f"{hero['bosses_defeated']} bosses slain"))
        recs = sorted(hero["records"].values(), key=lambda r: r.get("date", ""), reverse=True)
        rec_rows = [ft.Row([ft.Text(r.get("name", "?"), expand=True),
                            muted(core.record_text(r, units))]) for r in recs[:15]]
        ach_rows = []
        for aid, name, desc in core.ACHIEVEMENTS:
            got = aid in hero["achievements"]
            ach_rows.append(ft.Row([
                ft.Icon(ft.Icons.MILITARY_TECH if got else ft.Icons.LOCK_OUTLINE,
                        color=ft.Colors.AMBER_400 if got else ft.Colors.ON_SURFACE_VARIANT),
                ft.Column([ft.Text(name, weight=ft.FontWeight.BOLD if got else None),
                           muted(desc, 12)], spacing=0, expand=True)]))
        return [info,
                ft.OutlinedButton("Exercise library", icon=ft.Icons.MENU_BOOK, height=48,
                                  on_click=self.open_library),
                card(title("Personal records", 16),
                     *(rec_rows or [muted("Finish a workout to set records.")])),
                card(title("Achievements", 16), *ach_rows),
                muted(f"Data folder: {self.store.base_dir}", 11)]


PREFS_PREFIX = "ironquest."


def use_browser_storage():
    """True in the web version (Python running inside the browser via Pyodide).
    Set IRONQUEST_BROWSER_STORAGE=1 to try browser storage while testing on the PC."""
    return sys.platform == "emscripten" or bool(os.environ.get("IRONQUEST_BROWSER_STORAGE"))


async def browser_backend(page):
    """Load saved data from the browser's storage and keep it updated.

    A website can't keep JSON files, so the web version stores the same JSON
    text under three keys with Flet's SharedPreferences (browser local storage).
    """
    prefs = ft.SharedPreferences()
    texts = {}
    for key in core.STORE_KEYS:
        value = await prefs.get(PREFS_PREFIX + key)
        if isinstance(value, str):
            texts[key] = value
    queue = asyncio.Queue()

    async def writer():                 # one write at a time, in order
        while True:
            key, text = await queue.get()
            try:
                if text is None:
                    await prefs.remove(PREFS_PREFIX + key)
                else:
                    await prefs.set(PREFS_PREFIX + key, text)
            except Exception as err:    # keep going; the next save retries
                print(f"Could not save {key} to browser storage: {err}")

    page.run_task(writer)
    return core.MemoryBackend(texts, on_change=lambda k, t: queue.put_nowait((k, t)))


async def main(page: ft.Page):
    backend = await browser_backend(page) if use_browser_storage() else None
    IronQuestMobile(page, backend)


if __name__ == "__main__":
    ft.run(main)
