"""
ironquest_core - IronQuest game logic with no GUI.

Split out of the desktop app (../Rhodes.py) so the phone version (main.py,
Flet) and the desktop version share the same rules: constants, exercise
library and how-to guides, validation, DataStore, XP/levels/stats, boss,
quests, achievements, fatigue, the workout generator and finish_workout.

This module must not import tkinter, customtkinter or matplotlib.
"""

import copy
import datetime as dt
import json
import math
import os
import random
import re
import shutil

# =====================================================================
#  CONSTANTS
# =====================================================================

APP_NAME = "IronQuest"
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
# On a phone, Flet sets FLET_APP_STORAGE_DATA to the app's private, writable
# storage folder. On a PC (or in tests) fall back to this script's folder.
BASE_DIR = os.environ.get("FLET_APP_STORAGE_DATA") or SCRIPT_DIR
EXERCISES_FILE = "exercises.json"
HERO_FILE = "hero.json"
WORKOUTS_FILE = "workouts.json"

LB_PER_KG = 2.20462

MUSCLES = ["chest", "shoulders", "triceps", "back", "biceps", "forearms",
           "core", "quads", "hamstrings", "glutes", "calves"]
PATTERNS = ["push", "pull", "squat", "hinge", "lunge", "core", "carry",
            "cardio", "mobility"]
UPPER_PATTERNS = {"push", "pull"}
LOWER_PATTERNS = {"squat", "hinge", "lunge"}
EQUIPMENT = ["dumbbells", "barbell", "kettlebell", "pull-up bar", "bench",
             "bands", "jump rope"]
WEIGHTED_EQUIPMENT = {"dumbbells", "barbell", "kettlebell"}
CATEGORIES = ["compound", "accessory", "core", "cardio", "mobility"]
STATS = ["STR", "END", "AGI", "VIT"]
STAT_NAMES = {"STR": "Strength", "END": "Endurance", "AGI": "Agility",
              "VIT": "Vitality"}

# XP multipliers (see design plan section 4)
TYPE_MULT = {"compound": 1.5, "accessory": 1.0, "core": 1.0, "cardio": 1.2,
             "mobility": 0.6}
DIFF_MULT = {1: 1.00, 2: 1.15, 3: 1.30}
EFFORT_MULT = {"easy": 0.8, "moderate": 1.0, "hard": 1.3}
EFFORTS = ["easy", "moderate", "hard"]
TIRED_THRESHOLD = 80          # fatigue % above which a set earns less XP
TIRED_PENALTY = 0.7
PR_BONUS = 15
STAT_XP_PER_POINT = 25
FATIGUE_HALF_LIFE_H = 24
FATIGUE_PRIMARY = 8           # fatigue % added per set to each primary muscle
FATIGUE_SECONDARY = 3
STREAK_GAP_DAYS = 3           # up to 2 rest days keeps a streak alive
BOSS_BONUS = 100

GOALS = {"Strength": "STR", "Muscle": "VIT", "Conditioning": "END",
         "General": "AGI"}
GOAL_TO_FOCUS = {"Strength": "Strength", "Muscle": "Muscle",
                 "Conditioning": "Conditioning", "General": "Full Body"}
CLASSES = {
    "STR": ("Juggernaut", "Unstoppable force. Lives under the barbell."),
    "END": ("Ranger", "Goes the distance. Never runs out of road."),
    "AGI": ("Monk", "Fast, mobile, and in total control of every rep."),
    "VIT": ("Paladin", "Rock-solid core and the resilience to match."),
    "ALL": ("Champion", "Balanced in all things. A true all-rounder."),
}
TRAINING_LEVELS = {1: "Beginner", 2: "Intermediate", 3: "Advanced"}
LEVEL_LOAD = {1: 1.0, 2: 1.5, 3: 2.0}      # starting-weight multiplier
LEVEL_REPS = {1: 0.7, 2: 1.0, 3: 1.3}      # bodyweight rep multiplier
FOCUSES = ["Full Body", "Strength", "Muscle", "Conditioning", "Upper", "Lower"]
WORKOUT_NAMES = {"Strength": "Trial of Iron", "Muscle": "Forge of Might",
                 "Conditioning": "The Gauntlet", "Full Body": "Hero's Circuit",
                 "Upper": "Skyward Assault", "Lower": "Earthshaker",
                 "Custom": "Freestyle Quest"}

# Input limits (stored internally in pounds)
REPS_RANGE = (1, 100)
WEIGHT_RANGE_LB = (0, 1000)
WEIGHT_RANGE_KG = (0, 450)
MINUTES_RANGE = (0.25, 180)
BODYWEIGHT_RANGE_LB = (60, 500)
BODYWEIGHT_RANGE_KG = (28, 226)      # stays inside the lb range after conversion
DAYS_RANGE = (2, 6)
NAME_MAX = 20
EXERCISE_NAME_MAX = 30
DESC_MIN, DESC_MAX = 10, 600      # custom exercise how-to description
CUSTOM_SOURCE = "Your own description"

BASELINE_TESTS = {
    "pushups": {"label": "Max push-ups", "lo": 0, "hi": 150,
                "beg": 15, "adv": 40},
    "pullups": {"label": "Max pull-ups", "lo": 0, "hi": 50,
                "beg": 3, "adv": 12},
    "squats": {"label": "Bodyweight squats in 60 seconds", "lo": 0, "hi": 120,
               "beg": 30, "adv": 50},
    "mile": {"label": "Mile run time (mm:ss)", "lo": 240, "hi": 1500,
             "beg": 600, "adv": 420, "lower_better": True},
}

BOSSES = [
    ("Lord Lethargy", "A sluggish tyrant who feeds on skipped workouts."),
    ("The Couch Wraith", "It whispers 'just one more episode'..."),
    ("Sir Skips-Leg-Day", "Massive arms. Toothpick legs. Pure arrogance."),
    ("The Donut Dragon", "Hoards sugar and guards the break room."),
    ("Baron Burnout", "Preys on heroes who never take a rest day."),
    ("The Snooze Hydra", "Hit snooze once and two more heads grow back."),
    ("Procrastinator Prime", "Will absolutely fight you... tomorrow."),
    ("The Iron Golem", "Forged from every plate you never lifted."),
]

QUEST_POOL = {
    "train_days": ("Train {n} days this week", 60),
    "pull_sets": ("Complete {n} pulling sets", 40),
    "push_sets": ("Complete {n} pushing sets", 40),
    "lower_sets": ("Complete {n} lower-body sets", 40),
    "core_sets": ("Complete {n} core sets", 30),
    "cardio_min": ("Log {n} minutes of cardio", 40),
    "set_pr": ("Set a new personal record", 50),
    "earn_xp": ("Earn {n} XP from workouts", 50),
    "balanced": ("Finish a workout with 4+ movement patterns", 40),
}
QUEST_TARGETS = {"pull_sets": 10, "push_sets": 10, "lower_sets": 12,
                 "core_sets": 8, "cardio_min": 30, "set_pr": 1,
                 "earn_xp": 500, "balanced": 1}

ACHIEVEMENTS = [
    ("first_workout", "First Rep", "Complete your first workout"),
    ("workouts_10", "Dedicated", "Complete 10 workouts"),
    ("workouts_25", "Iron Habit", "Complete 25 workouts"),
    ("level_5", "Rising Hero", "Reach level 5"),
    ("level_10", "Veteran", "Reach level 10"),
    ("level_20", "Legend", "Reach level 20"),
    ("boss_1", "Boss Slayer", "Defeat a weekly boss"),
    ("boss_5", "Dragon Hunter", "Defeat 5 weekly bosses"),
    ("pr_5", "Record Breaker", "Break 5 personal records"),
    ("streak_5", "On Fire", "Reach a 5-session streak"),
    ("ten_ton", "Ten-Ton Club", "Lift 20,000 lb in total"),
    ("road_warrior", "Road Warrior", "Log 300 minutes of cardio"),
    ("well_rounded", "Well-Rounded", "Raise every stat to 15"),
]

# Workout generator: slot = (preferred category code, allowed patterns)
# C = compound, A = accessory, X = cardio, * = anything
SLOT_PLANS = {
    "Full Body": [("C", ["squat", "hinge"]), ("C", ["push"]), ("C", ["pull"]),
                  ("A", ["lunge", "hinge", "squat"]), ("A", ["push"]),
                  ("A", ["pull"]), ("A", ["carry"]), ("A", ["push", "pull"])],
    "Strength": [("C", ["squat", "hinge"]), ("C", ["push"]), ("C", ["pull"]),
                 ("C", ["hinge", "squat"]), ("A", ["push", "pull"]),
                 ("A", ["carry"])],
    "Muscle": [("C", ["squat", "hinge"]), ("C", ["push"]), ("C", ["pull"]),
               ("A", ["lunge", "hinge"]), ("A", ["push"]), ("A", ["pull"]),
               ("A", ["push", "pull"]), ("A", ["squat", "lunge"])],
    "Conditioning": [("X", ["cardio"]), ("*", ["squat", "lunge"]),
                     ("*", ["push"]), ("X", ["cardio"]),
                     ("*", ["pull", "hinge"]), ("X", ["cardio"]),
                     ("*", ["lunge", "squat"]), ("*", ["push", "pull"])],
    "Upper": [("C", ["push"]), ("C", ["pull"]), ("A", ["push"]),
              ("A", ["pull"]), ("A", ["push"]), ("A", ["pull"]),
              ("A", ["carry"])],
    "Lower": [("C", ["squat"]), ("C", ["hinge"]), ("C", ["lunge"]),
              ("A", ["squat", "hinge"]), ("A", ["lunge", "squat"]),
              ("A", ["hinge"])],
}
# (sets, reps, rest seconds) by focus and slot type
SCHEMES = {
    "Strength": {"C": (5, 5, 120), "A": (3, 8, 75)},
    "Muscle": {"C": (4, 10, 90), "A": (3, 12, 60)},
    "Full Body": {"C": (3, 10, 90), "A": (3, 12, 60)},
    "Upper": {"C": (4, 8, 90), "A": (3, 12, 60)},
    "Lower": {"C": (4, 8, 90), "A": (3, 12, 60)},
    "Conditioning": {"C": (3, 15, 30), "A": (3, 15, 30)},
}


def _ex(id_, name, pattern, cat, primary, secondary, equip, diff, stat, kind,
        bw, sets, amount, pct=0.0, per_hand=False, role=""):
    """Compact builder for the default exercise library."""
    amount_key = "reps" if kind == "reps" else "minutes"
    return {"id": id_, "name": name, "pattern": pattern, "category": cat,
            "primary": primary, "secondary": secondary, "equipment": equip,
            "difficulty": diff, "stat": stat, "kind": kind, "bw_factor": bw,
            "default": {"sets": sets, amount_key: amount}, "start_pct": pct,
            "per_hand": per_hand, "role": role, "custom": False}


DEFAULT_EXERCISES = [
    # ---------------- PUSH ----------------
    _ex("push_up", "Push-Up", "push", "compound", ["chest", "triceps"],
        ["shoulders", "core"], [], 1, "STR", "reps", 0.65, 3, 12),
    _ex("incline_push_up", "Incline Push-Up", "push", "accessory",
        ["chest", "triceps"], ["shoulders"], [], 1, "STR", "reps", 0.45, 3, 12),
    _ex("diamond_push_up", "Diamond Push-Up", "push", "accessory",
        ["triceps", "chest"], ["shoulders"], [], 2, "STR", "reps", 0.65, 3, 10),
    _ex("pike_push_up", "Pike Push-Up", "push", "accessory",
        ["shoulders", "triceps"], ["core"], [], 2, "STR", "reps", 0.7, 3, 8),
    _ex("bench_dip", "Bench Dip", "push", "accessory", ["triceps"],
        ["chest", "shoulders"], ["bench"], 1, "STR", "reps", 0.5, 3, 12),
    _ex("db_bench_press", "Dumbbell Bench Press", "push", "compound",
        ["chest", "triceps"], ["shoulders"], ["dumbbells", "bench"], 1, "STR",
        "reps", 0, 3, 10, 0.2, True),
    _ex("db_shoulder_press", "Dumbbell Shoulder Press", "push", "compound",
        ["shoulders", "triceps"], ["core"], ["dumbbells"], 1, "STR", "reps",
        0, 3, 10, 0.12, True),
    _ex("bb_bench_press", "Barbell Bench Press", "push", "compound",
        ["chest", "triceps"], ["shoulders"], ["barbell", "bench"], 2, "STR",
        "reps", 0, 4, 8, 0.5),
    _ex("overhead_press", "Barbell Overhead Press", "push", "compound",
        ["shoulders", "triceps"], ["core"], ["barbell"], 2, "STR", "reps",
        0, 4, 8, 0.3),
    _ex("db_incline_press", "Incline Dumbbell Press", "push", "accessory",
        ["chest", "shoulders"], ["triceps"], ["dumbbells", "bench"], 2, "STR",
        "reps", 0, 3, 10, 0.17, True),
    _ex("lateral_raise", "Lateral Raise", "push", "accessory", ["shoulders"],
        [], ["dumbbells"], 1, "VIT", "reps", 0, 3, 12, 0.04, True),
    _ex("overhead_tri_ext", "Overhead Triceps Extension", "push", "accessory",
        ["triceps"], ["shoulders"], ["dumbbells"], 1, "STR", "reps",
        0, 3, 12, 0.1),
    # ---------------- PULL ----------------
    _ex("pull_up", "Pull-Up", "pull", "compound", ["back", "biceps"],
        ["forearms", "core"], ["pull-up bar"], 2, "STR", "reps", 1.0, 3, 6),
    _ex("chin_up", "Chin-Up", "pull", "compound", ["biceps", "back"],
        ["forearms"], ["pull-up bar"], 2, "STR", "reps", 1.0, 3, 6),
    _ex("negative_pull_up", "Negative Pull-Up", "pull", "accessory",
        ["back", "biceps"], ["forearms"], ["pull-up bar"], 1, "STR", "reps",
        1.0, 3, 5),
    _ex("inverted_row", "Inverted Row", "pull", "compound", ["back", "biceps"],
        ["core"], ["pull-up bar"], 1, "STR", "reps", 0.5, 3, 10),
    _ex("db_row", "One-Arm Dumbbell Row", "pull", "compound",
        ["back", "biceps"], ["forearms"], ["dumbbells"], 1, "STR", "reps",
        0, 3, 10, 0.2),
    _ex("bb_row", "Barbell Bent-Over Row", "pull", "compound",
        ["back", "biceps"], ["forearms", "hamstrings"], ["barbell"], 2, "STR",
        "reps", 0, 4, 8, 0.4),
    _ex("renegade_row", "Renegade Row", "pull", "compound", ["back", "core"],
        ["biceps", "shoulders"], ["dumbbells"], 3, "AGI", "reps", 0.3, 3, 8,
        0.1, True),
    _ex("doorframe_row", "Doorframe Row", "pull", "accessory",
        ["back", "biceps"], ["forearms"], [], 1, "STR", "reps", 0.35, 3, 12),
    _ex("prone_ytw", "Prone Y-T-W Raise", "pull", "accessory",
        ["shoulders", "back"], [], [], 1, "VIT", "reps", 0.05, 3, 10),
    _ex("band_row", "Band Row", "pull", "accessory", ["back", "biceps"], [],
        ["bands"], 1, "VIT", "reps", 0, 3, 15),
    _ex("band_pull_apart", "Band Pull-Apart", "pull", "accessory",
        ["shoulders", "back"], [], ["bands"], 1, "VIT", "reps", 0, 3, 15),
    _ex("rear_delt_fly", "Rear Delt Fly", "pull", "accessory",
        ["shoulders", "back"], [], ["dumbbells"], 1, "VIT", "reps", 0, 3, 12,
        0.04, True),
    _ex("db_curl", "Dumbbell Curl", "pull", "accessory", ["biceps"],
        ["forearms"], ["dumbbells"], 1, "STR", "reps", 0, 3, 12, 0.08, True),
    _ex("hammer_curl", "Hammer Curl", "pull", "accessory",
        ["biceps", "forearms"], [], ["dumbbells"], 1, "STR", "reps", 0, 3, 12,
        0.08, True),
    _ex("bb_curl", "Barbell Curl", "pull", "accessory", ["biceps"],
        ["forearms"], ["barbell"], 1, "STR", "reps", 0, 3, 10, 0.2),
    _ex("kb_high_pull", "Kettlebell High Pull", "pull", "accessory",
        ["shoulders", "back"], ["glutes"], ["kettlebell"], 2, "AGI", "reps",
        0, 3, 12, 0.15),
    # ---------------- SQUAT ----------------
    _ex("air_squat", "Bodyweight Squat", "squat", "compound",
        ["quads", "glutes"], ["core"], [], 1, "END", "reps", 0.7, 3, 15),
    _ex("goblet_squat", "Goblet Squat", "squat", "compound",
        ["quads", "glutes"], ["core"], ["dumbbells"], 1, "STR", "reps",
        0.85, 3, 10, 0.15),
    _ex("bb_back_squat", "Barbell Back Squat", "squat", "compound",
        ["quads", "glutes"], ["hamstrings", "core"], ["barbell"], 2, "STR",
        "reps", 0.85, 4, 8, 0.6),
    _ex("front_squat", "Barbell Front Squat", "squat", "compound",
        ["quads", "glutes"], ["core", "back"], ["barbell"], 3, "STR", "reps",
        0.85, 4, 6, 0.5),
    _ex("kb_goblet_squat", "Kettlebell Goblet Squat", "squat", "compound",
        ["quads", "glutes"], ["core"], ["kettlebell"], 1, "STR", "reps",
        0.85, 3, 10, 0.15),
    _ex("jump_squat", "Jump Squat", "squat", "accessory", ["quads", "glutes"],
        ["calves"], [], 2, "AGI", "reps", 0.8, 3, 10),
    _ex("box_pistol", "Assisted Pistol Squat", "squat", "accessory",
        ["quads", "glutes"], ["core"], ["bench"], 3, "AGI", "reps", 0.9, 3, 6),
    _ex("wall_sit", "Wall Sit", "squat", "accessory", ["quads"], ["glutes"],
        [], 1, "END", "timed", 0, 3, 0.75),
    _ex("calf_raise", "Calf Raise", "squat", "accessory", ["calves"], [], [],
        1, "END", "reps", 0.9, 3, 20),
    # ---------------- HINGE ----------------
    _ex("glute_bridge", "Glute Bridge", "hinge", "accessory",
        ["glutes", "hamstrings"], ["core"], [], 1, "VIT", "reps", 0.4, 3, 15),
    _ex("db_rdl", "Dumbbell Romanian Deadlift", "hinge", "compound",
        ["hamstrings", "glutes"], ["back", "forearms"], ["dumbbells"], 1, "STR",
        "reps", 0, 3, 10, 0.15, True),
    _ex("bb_deadlift", "Barbell Deadlift", "hinge", "compound",
        ["hamstrings", "glutes", "back"], ["forearms", "quads", "core"],
        ["barbell"], 2, "STR", "reps", 0, 3, 5, 0.8),
    _ex("kb_swing", "Kettlebell Swing", "hinge", "compound",
        ["glutes", "hamstrings"], ["core", "shoulders"], ["kettlebell"], 2,
        "END", "reps", 0, 3, 15, 0.15),
    _ex("hip_thrust", "Barbell Hip Thrust", "hinge", "accessory", ["glutes"],
        ["hamstrings"], ["barbell", "bench"], 2, "STR", "reps", 0, 3, 10, 0.5),
    _ex("good_morning", "Good Morning", "hinge", "accessory",
        ["hamstrings", "back"], ["glutes"], ["barbell"], 2, "STR", "reps",
        0, 3, 10, 0.25),
    _ex("sl_rdl", "Single-Leg Dumbbell RDL", "hinge", "accessory",
        ["hamstrings", "glutes"], ["core"], ["dumbbells"], 2, "AGI", "reps",
        0, 3, 8, 0.1),
    _ex("superman", "Superman Hold", "hinge", "accessory", ["back", "glutes"],
        [], [], 1, "VIT", "reps", 0.2, 3, 12),
    # ---------------- LUNGE ----------------
    _ex("reverse_lunge", "Reverse Lunge", "lunge", "accessory",
        ["quads", "glutes"], ["hamstrings"], [], 1, "AGI", "reps", 0.7, 3, 10),
    _ex("walking_lunge", "Dumbbell Walking Lunge", "lunge", "compound",
        ["quads", "glutes"], ["hamstrings", "forearms"], ["dumbbells"], 2,
        "STR", "reps", 0.7, 3, 10, 0.1, True),
    _ex("bulgarian_split_squat", "Bulgarian Split Squat", "lunge", "compound",
        ["quads", "glutes"], ["hamstrings"], ["dumbbells", "bench"], 2, "STR",
        "reps", 0.8, 3, 8, 0.1, True),
    _ex("step_up", "Step-Up", "lunge", "accessory", ["quads", "glutes"],
        ["calves"], ["bench"], 1, "END", "reps", 0.8, 3, 10),
    _ex("lateral_lunge", "Lateral Lunge", "lunge", "accessory",
        ["quads", "glutes"], ["hamstrings"], [], 1, "AGI", "reps", 0.7, 3, 10),
    # ---------------- CORE ----------------
    _ex("plank", "Plank", "core", "core", ["core"], ["shoulders"], [], 1,
        "VIT", "timed", 0, 3, 0.75),
    _ex("side_plank", "Side Plank", "core", "core", ["core"], ["shoulders"],
        [], 1, "VIT", "timed", 0, 2, 0.5),
    _ex("dead_bug", "Dead Bug", "core", "core", ["core"], [], [], 1, "VIT",
        "reps", 0.1, 3, 12),
    _ex("hollow_hold", "Hollow Body Hold", "core", "core", ["core"], [], [],
        2, "VIT", "timed", 0, 3, 0.5),
    _ex("hanging_knee_raise", "Hanging Knee Raise", "core", "core", ["core"],
        ["forearms"], ["pull-up bar"], 2, "VIT", "reps", 0.3, 3, 12),
    _ex("russian_twist", "Russian Twist", "core", "core", ["core"], [], [], 1,
        "VIT", "reps", 0.1, 3, 20),
    _ex("bird_dog", "Bird Dog", "core", "core", ["core", "back"], ["glutes"],
        [], 1, "VIT", "reps", 0.1, 3, 10),
    _ex("mountain_climber", "Mountain Climbers", "core", "core",
        ["core", "shoulders"], ["quads"], [], 1, "END", "timed", 0, 3, 0.5),
    # ---------------- CARRY ----------------
    _ex("farmer_carry", "Farmer's Carry", "carry", "accessory",
        ["forearms", "core"], ["shoulders", "back"], ["dumbbells"], 1, "STR",
        "timed", 0, 3, 0.75),
    _ex("suitcase_carry", "Suitcase Carry", "carry", "accessory",
        ["core", "forearms"], ["shoulders"], ["kettlebell"], 1, "VIT", "timed",
        0, 3, 0.5),
    # ---------------- CARDIO ----------------
    _ex("run", "Run", "cardio", "cardio", ["quads", "calves"],
        ["hamstrings", "glutes"], [], 1, "END", "timed", 0, 1, 20),
    _ex("ruck_march", "Ruck March", "cardio", "cardio", ["quads", "back"],
        ["calves", "core"], [], 2, "END", "timed", 0, 1, 45),
    _ex("sprint_intervals", "Sprint Intervals", "cardio", "cardio",
        ["quads", "hamstrings"], ["calves", "glutes"], [], 3, "AGI", "timed",
        0, 1, 10),
    _ex("jump_rope", "Jump Rope", "cardio", "cardio", ["calves"],
        ["shoulders"], ["jump rope"], 1, "AGI", "timed", 0, 3, 2),
    _ex("burpee", "Burpees", "cardio", "cardio", ["quads", "chest"],
        ["shoulders", "core"], [], 2, "END", "reps", 0.5, 3, 10),
    _ex("high_knees", "High Knees", "cardio", "cardio", ["quads", "core"],
        ["calves"], [], 1, "AGI", "timed", 0, 3, 0.5),
    _ex("jumping_jacks", "Jumping Jacks", "cardio", "cardio",
        ["calves", "shoulders"], [], [], 1, "END", "timed", 0, 2, 1),
    _ex("broad_jump", "Broad Jump", "cardio", "cardio", ["quads", "glutes"],
        ["calves"], [], 2, "AGI", "reps", 0.8, 3, 6),
    _ex("skater_hops", "Skater Hops", "cardio", "cardio", ["glutes", "quads"],
        ["calves"], [], 1, "AGI", "timed", 0, 3, 0.5),
    # ---------------- MOBILITY ----------------
    _ex("worlds_greatest", "World's Greatest Stretch", "mobility", "mobility",
        ["hamstrings", "glutes"], ["back", "shoulders"], [], 1, "AGI", "timed",
        0, 1, 1, role="warmup"),
    _ex("arm_circles", "Arm Circles", "mobility", "mobility", ["shoulders"],
        [], [], 1, "AGI", "timed", 0, 1, 0.5, role="warmup"),
    _ex("leg_swings", "Leg Swings", "mobility", "mobility",
        ["glutes", "hamstrings"], [], [], 1, "AGI", "timed", 0, 1, 0.5,
        role="warmup"),
    _ex("inchworm", "Inchworm", "mobility", "mobility",
        ["hamstrings", "shoulders"], ["core"], [], 1, "AGI", "reps", 0.3, 1, 6,
        role="warmup"),
    _ex("band_dislocate", "Band Shoulder Dislocates", "mobility", "mobility",
        ["shoulders"], ["chest"], ["bands"], 1, "AGI", "reps", 0, 1, 10,
        role="warmup"),
    _ex("cat_cow", "Cat-Cow", "mobility", "mobility", ["back", "core"], [],
        [], 1, "AGI", "timed", 0, 1, 1, role="both"),
    _ex("hip_flexor_stretch", "Hip Flexor Stretch", "mobility", "mobility",
        ["quads", "glutes"], [], [], 1, "AGI", "timed", 0, 1, 1,
        role="cooldown"),
    _ex("hamstring_stretch", "Hamstring Stretch", "mobility", "mobility",
        ["hamstrings"], [], [], 1, "AGI", "timed", 0, 1, 1, role="cooldown"),
    _ex("childs_pose", "Child's Pose", "mobility", "mobility",
        ["back", "shoulders"], [], [], 1, "AGI", "timed", 0, 1, 1,
        role="cooldown"),
    _ex("chest_opener", "Chest Opener Stretch", "mobility", "mobility",
        ["chest", "shoulders"], [], [], 1, "AGI", "timed", 0, 1, 1,
        role="cooldown"),
]

# How-to guides shown when hovering over an exercise. Most text is quoted from
# openly licensed sources; the credit is stored with each one:
#   - wger.de exercise wiki (CC BY-SA / CC0, author named per entry)
#   - U.S. Army ATP 7-22.02 Holistic Health and Fitness Drills and Exercises (public domain)
#   - a few written for this app where no licensed source existed (marked as such)
HOW_TO = {
    'push_up': ('Start in a plank position with hands placed slightly wider than shoulder-width, feet together, and body in a straight line from head to heels. Engage your core and lower your body by bending your elbows, keeping them close to your body or flared slightly outward. Lower until your chest nearly touches the ground while maintaining a neutral spine. Push through your palms to return to the starting position, fully extending your arms.',
        '"Push-Up" by Settebello, wger.de, CC BY-SA 4.0 (excerpt)'),
    'diamond_push_up': ('Start: Get into a plank. Place hands close together under your chest so thumbs and index fingers form a diamond shape. Lower: Bend your elbows to lower your chest toward your hands. Keep your body straight. Push: Push back up until arms are fully extended. Keep elbows close to your body and core tight.',
        '"Diamond push ups" by notdefine, wger.de, CC BY-SA 4.0'),
    'bench_dip': ('Starting position: Sit down on the front edge of a chair, back straight, hands holding the front edge. Still holding the edge of the chair, arms extended, lift your butt and walk forward slightly so that it is a few inches from the chair. Steps: Slowly lower your body, keeping the back straight, until your arms are at a right angle. Raise your body again to the initial position, arms extended. Repeat.',
        '"Chair dips" by tinman, wger.de, CC BY-SA 4.0'),
    'db_bench_press': ('Setup and Starting Position: Sit at the end of a flat bench with a dumbbell resting vertically against each thigh. Carefully lean back while driving the dumbbells toward your chest with your knees. The “Leg Drive” and Posture: Plant your feet firmly on the floor. Retract your shoulder blades (press them together against the bench) and maintain a slight natural lumbar curve. Starting Position: Push the dumbbells toward the ceiling. Your wrists should be aligned with your elbows. Rotate the dumbbells slightly inward (about 45 degrees) so that your elbows do not splay out too far to the sides, thereby protecting your shoulders. Eccentric Phase (Lowering): Lower the dumbbells in a controlled manner toward the sides of your chest. Your elbows should lower at an angle of about 45–60 degrees relative to your body. Feel the stretch in the lower part of your chest. Concentric Phase (Lift): Push the weight upward in a slight arc (toward the center), without letting the dumbbells collide at the top or fully locking out your elbows to maintain muscle tension. Exhale as you lift. Translated with DeepL.com (free version)',
        '"Benchpress Dumbbells" by wger.de, wger.de, CC BY-SA 3.0'),
    'db_shoulder_press': ("Sit on a bench, the back rest should be almost vertical. Take two dumbbells and bring them up to shoulder height, the palms and the elbows point during the whole exercise to the front. Press the weights up, at the highest point they come very near but don't touch. Go slowly down and repeat.",
        '"Shoulder Press, Dumbbells" by wger.de, wger.de, CC BY-SA 3.0'),
    'bb_bench_press': ("Lay down on a bench, the bar should be directly above your eyes, the knees are somewhat angled and the feet are firmly on the floor. Concentrate, breath deeply and grab the bar more than shoulder wide. Bring it slowly down till it briefly touches your chest at the height of your nipples. Push the bar up. If you train with a high weight it is advisable to have a spotter that can help you up if you can't lift the weight on your own. With the width of the grip you can also control which part of the chest is trained more: wide grip: outer chest muscles narrow grip: inner chest muscles and triceps",
        '"Bench Press" by sistab2, wger.de, CC BY-SA 3.0'),
    'overhead_press': ('Setup: Stand with feet together and grip the bar slightly wider than shoulders. Position: Rest the bar on your upper chest. Press: Brace your core and push the bar straight up until your arms lock out. Finish: Control the bar back down to your chest.',
        '"Overhead Barbell Press" by nishant0712, wger.de, CC BY-SA 4.0'),
    'db_incline_press': ('Set the bench to an incline of between 30 and 45 degrees (an incline greater than 45° will place too much strain on the shoulders and reduce the stimulus to the chest). Sit down with a dumbbell on each thigh. Starting position: Lean back, resting your back against the bench, while using your knees one after the other to push the dumbbells upward to shoulder height. Anatomical Stabilization: Plant your feet firmly on the floor. Retract your scapulas (bring your shoulder blades together and press them into the bench) to protect your shoulders and stabilize the load. Eccentric Phase (Lowering): Lower the dumbbells slowly and in a controlled manner toward the upper part of your chest. Your elbows should not splay out to the sides (90°); maintain a safe angle of about 45 to 60 degrees relative to your torso. Concentric Phase (Lift): Push the dumbbells vertically upward as you exhale. Follow a slightly converging path (without letting them touch at the top). Stop the movement just before locking out your elbows to maintain muscle tension in the upper pectoral.',
        '"Incline Bench Press - Dumbbell" by wger.de, wger.de, CC BY-SA 3.0 (excerpt)'),
    'lateral_raise': ('This exercise works the deltoid muscle of the shoulder. The movement starts with the arms straight, and the hands holding weights at the sides or in front of the body. Body is in a slight forward-leaning position with hips and knees bent a little. Arms are kept straight or slightly bent, and raised through an arc of movement in the coronal plane that terminates when the hands are at approximately shoulder height. Weights are lowered to the starting position, completing one rep. When using a cable machine the individual stands with the coronal plane in line with the pulley, which is at or near the ground. The exercise can be completed one shoulder at a time (with the other hand used to stabilize the body against the weight moved), or with both hands simultaneously if two parallel pulleys are available.',
        '"Lateral Raises" by wger.de, wger.de, CC BY-SA 3.0'),
    'overhead_tri_ext': ('Position one dumbbell over head with both hands under inner plate (heart shaped grip). With elbows over head, lower forearm behind upper arm by flexing elbows. Flex wrists at bottom to avoid hitting dumbbell on back of neck. Raise dumbbell over head by extending elbows while hyperextending wrists. Return and repeat.',
        '"Dumbbell Triceps Extension" by tuninx, wger.de, CC BY-SA 3.0'),
    'pull_up': ('Grab the pull up bar with a wide grip, the body is hanging freely. Keep your chest out and pull yourself up till your chin reaches the bar or it touches your neck, if you want to pull behind you. Go with a slow and controlled movement down, always keeping the chest out.',
        '"Pull-ups" by wger.de, wger.de, CC BY-SA 3.0'),
    'chin_up': ("The chin-up (also known as a chin or chinup) is a strength training exercise. People frequently do this exercise with the intention of strengthening muscles such as the latissimus dorsi and biceps, which extend the shoulder and flex the elbow, respectively. In this maneuver, the palms are faced towards the body. It is a form of pull-up in which the range of motion is established in relation to a person's chin.",
        '"Chin Up" by BFad07, wger.de, CC0'),
    'negative_pull_up': ('Stand on a box or bench under a pull-up bar and step up so your chin is above the bar with your elbows fully bent. Take your feet off the box and lower yourself as slowly as you can, aiming for five seconds, until your arms are straight. Step back onto the box and repeat. This builds the strength needed for full pull-ups.',
        '"Slow Eccentric Pull-Up Negative" by lightking, wger.de, CC BY-SA 4.0'),
    'inverted_row': ("Lie down under a high bar or suspension bar, positioned at an appropriate height. Position yourself on your back under the bar, gripping the bar with a supinated grip (palms facing you). Adjust your position so that your body is aligned straight from head to toe. Arms should be fully extended, shoulders stabilized, and legs aligned with the rest of the body. Bend your elbows and pull your chest towards the bar, contracting your back muscles. Imagine you're trying to bring your shoulder blades together. Hold the contraction at the top of the movement for a moment to maximize muscle activation. Slowly return to the starting position, extending your elbows.",
        '"Australian pull-ups" by PaukOne, wger.de, CC BY-SA 4.0'),
    'db_row': ('With dumbbells in hand, bend at the hip until hands hang just below the knees (similar to straight-legged-deadlift starting position). Keep upper body angle constant while contracting your lats to pull you ellbows back pinching the shoulder blades at the top. Try not to stand up with every rep, check hands go below knees on every rep.',
        '"Bent Over Dumbbell Rows (Single Arm)" by sebk, wger.de, CC BY-SA 4.0'),
    'renegade_row': ('Get into pushup position gripping some dumbbells. Perform one pushup, then drive your left elbo up, bringing the dumbell up to your body. Return the dumbell to starting position. Perform another pushup and then row with the other arm to complete one rep.',
        '"Renegade Row" by fletchgraham, wger.de, CC0'),
    'prone_ytw': ('Starting Position: Stand with feet shoulder-width apart. Hinge forward at the hips (like a deadlift) keeping your back flat, or lie face down on an incline bench. Keep your thumbs pointing up throughout. Y (Arms up): Extend both arms straight forward and upward at a 135-degree angle from your body, forming a "Y". Squeeze your shoulder blades together at the top. T (Arms out): Open your arms straight out to the sides, perpendicular to your body, forming a "T". Focus on pinching your shoulder blades. W (Arms bent): Pull your elbows back, bending them to 90 degrees, and squeeze your shoulder blades to form a "W". Keep your wrists firm. L (Arms rotated): Start with elbows bent at 90 degrees and close to your body. Rotate your forearms outward (external rotation) like a goalpost, forming an "L" or a gate. Key Focus: Movements should be slow and controlled. Always lead with the thumbs and think about moving the shoulder blades, not just the arms.',
        '"YTWL Exercise" by teus_ergaster, wger.de, CC BY-SA 4.0 (excerpt)'),
    'band_row': ('Sit on the floor with your legs straight out in front of you and your back tall. Loop a resistance band around the soles of both feet and hold one end in each hand, arms extended and a slight bend in the knees. Pull the band toward your lower ribs by driving your elbows straight back and squeezing your shoulder blades together. Keep your chest up and your torso still rather than rocking backward to move the band. Extend the arms slowly to return. Because the torso stays upright and supported, this is a useful row when a bent-over position is uncomfortable, and it needs no anchor point.',
        '"Seated Band Row" by trs1800, wger.de, CC BY-SA 4.0'),
    'band_pull_apart': ('Hold the band with your arms extended in front of you at shoulder height. Keep your elbows slightly bent but fixed throughout the movement. Pull the band apart by spreading your arms until the band touches or comes close to your chest. Slowly bring your arms back to the starting position, controlling the tension on the band.',
        '"Band pull-aparts" by schwolfar, wger.de, CC BY-SA 4.0'),
    'rear_delt_fly': ('Sit on bench while holding weights. Bend forward as far as possible, with arms slightly bent at the elbow. Perform a lateral raise while maintaining the bend in your elbow.',
        '"Bent-over Lateral Raises" by apeschel, wger.de, CC BY-SA 4.0'),
    'db_curl': ("Hold two dumbbells, the arms are streched, the hands are on your side, the palms face inwards. Bend the arms and bring the weight with a fast movement up. At the same time, rotate your arms by 90 degrees at the very beginning of the movement. At the highest point, rotate a little the weights further outwards. Without a pause, bring them down, slowly. Don't allow your body to swing during the exercise, all work is done by the biceps, which are the only mucles that should move (pay attention to the elbows).",
        '"Biceps Curls With Dumbbell" by wger.de, wger.de, CC BY-SA 3.0'),
    'hammer_curl': ('Start: Hold dumbbells at your sides with palms facing your torso. Curl: Lift the weights toward your shoulders while maintaining the neutral grip (like holding a hammer). Squeeze: Contract the biceps at the top without moving your elbows forward. Lower: Slowly return to the starting position with full control.',
        '"Hammer Curls" by wger.de, wger.de, CC BY-SA 3.0'),
    'bb_curl': ("Hold the Barbell shoulder-wide, the back is straight, the shoulders slightly back, the arms are streched. Bend the arms, bringing the weight up, with a fast movement. Without pausing, let down the bar with a slow and controlled movement. Don't allow your body to swing during the exercise, all work is done by the biceps, which are the only mucles that should move (pay attention to the elbows).",
        '"Biceps Curls With Barbell" by wger.de, wger.de, CC BY-SA 3.0'),
    'kb_high_pull': ('Stand upright overtop of a kettlebell with your feet wider than shoulder-width apart angled out slightly. Maintain a braced core and neutral spine throughout the exercise. Hinge your hips backward and extend your arms to grab ahold the kettlebell with a double overhand grip. With you lower legs nearly vertical to the ground, extend your hips to raise the kettlebell with your elbows high keeping it close to your body. Once the kettlebell has reached shoulder height, lower back to the starting position.',
        '"Kettlebell sumo high pull" by wgerpott, wger.de, CC BY-SA 4.0 (excerpt)'),
    'air_squat': ('Stand upright with your chest slightly raised, your feet hip-width apart and your toes pointing straight ahead. Bring your hands to the back of your head with your fingers slightly interlaced and your elbows pointing to the side. Push your hips back and bend your knees, keeping your upper body as upright as possible. Push your knees outwards, they must never point towards each other. If your upper body moves slightly forward, make sure that it does not bend. Always keep your elbows level with your ears by tensing the muscles between your shoulder blades. If you are flexible enough, you can sink down until your buttocks touch your calves. However, make sure that you do not bend your spine. Before this happens, reverse the movement and use your heels and glutes to push yourself upwards with so much momentum that your feet lift off briefly and you do a little hop. If necessary, correct the position of your feet, arms and upper body before you move on to the next repetition. Translated with www. DeepL.com/Translator (free version)',
        '"Prisoner Squat" by lxmx, wger.de, CC BY-SA 4.0'),
    'goblet_squat': ('Grasp dumbbell with both hands at the sides of the upper plates. Hold dumbbell in front of chest, close to torso. Place feet about shoulderwide apart, keep knees slightly bent. Squat down until thighs are parallel to floor. Keep back straight, bend and move hips backward to keep knees above feet. Return, keep knees slightly flexed. Repeat. Keep bodyweight on heels and look ahead or slightly above to keep back straight.',
        '"Dumbbell Goblet Squat" by ataraxie67, wger.de, CC BY-SA 4.0'),
    'bb_back_squat': ('Place a barbell in a rack just below shoulder-height. Dip under the bar to put it behind the neck across the top of the back, and grip the bar with the hands wider than shoulder-width apart. Lift the chest up and squeeze the shoulder blades together to keep the straight back throughout the entire movement. Stand up to bring the bar off the rack and step backwards, then place the feet so that they are a little wider than shoulder-width apart. Sit back into hips and keep the back straight and the chest up, squatting down so the hips are below the knees. From the bottom of the squat, press feet into the ground and push hips forward to return to the top of the standing position.',
        '"Squats" by wger.de, wger.de, CC BY-SA 3.0'),
    'box_pistol': ('Stand on one leg, with your other leg straight and slightly forward. Bend one knee slowly, descending into a squat and keeping your back and your other leg straight. Slowly raise yourself from the squat, straightening the bent knee and keeping the other leg straight. Repeat.',
        '"Pistol squats right" by wger.de contributors, wger.de, CC BY-SA 4.0'),
    'wall_sit': ('Find a nice flat piece of wall and stand with your back leaning against the wall. Slowly slide down the wall while moving your feet away from it, until your thighs are parallel to the ground and both your knees and your hips are bent at a 90° angle. Cross your arms in front of your chest and hold this position for 30 seconds. Variant: put a big inflated rubber ball (like a small basketball) between your knees and squeeze the ball while holding the squat position',
        '"Wall Squat" by Blablabla, wger.de, CC0'),
    'calf_raise': ("Stand on the floor or on the edge of a step to increase the range of movement. Raise one foot. Lift your heel until you're standing on your toes. (variable) Stay in this position for three seconds Slowly lower your foot until you almost touch the ground with your heel - don't slam your foot!",
        '"Calf raises, right leg" by wger.de contributors, wger.de, CC BY-SA 4.0'),
    'glute_bridge': ('Lie on you back with your hips and knees flexed, feet on the ground. From this position, raise your butt off of the ground to a height where your body makes a straight line from your knees to your shoulders. To make the exercise more intense, you can add weight by letting a barbell rest on your hips as you complete the motion, or you can put your feet on a slightly higher surface such as a step or a bench.',
        '"Glute Bridge" by tdprice12, wger.de, CC BY-SA 4.0'),
    'db_rdl': ('This exercise involves holding a dumbbell in each hand and bending forward at the hips while keeping the back straight, then returning to a standing position. It primarily targets the hamstrings and glutes.',
        '"Dumbbell Romanian Deadlift" by AlucardEvil40, wger.de, CC BY-SA 4.0'),
    'bb_deadlift': ('Stand firmly, with your feet slightly more than shoulder wide apart. Stand directly behind the bar where it should barely touch your shin, your feet pointing a bit out. Bend down with a straight back, the knees also pointing somewhat out. Grab the bar with a shoulder wide grip, one overhand, one underhand (mixed grip). Pull the weight up. At the highest point make a slight hollow back and pull the bar back. Hold 1 or 2 seconds that position. Go down, making sure the back is not bent. Once down you can either go back again as soon as the weights touch the floor, or make a pause, depending on the weight.',
        '"Deadlifts" by wger.de, wger.de, CC BY-SA 3.0'),
    'kb_swing': ('Stand with your feet slightly wider than shoulder-width, the kettlebell on the floor about 20-30 cm in front of your toes. Hinge at the hips with a slight bend in the knees and a flat back, and grip the handle with both hands. Hike the kettlebell back between your legs, then drive your hips forward explosively so that it swings forward and up to chest or shoulder height (Russian style, not overhead). Your arms stay straight and relaxed, the power comes from the hips. Let the kettlebell swing back down, hinge again as it passes between your legs and go straight into the next rep.',
        '"2 Handed Kettlebell Swing" by deusinvictus, wger.de, CC BY-SA 4.0'),
    'hip_thrust': ('The bar should go directly on your upper thigh, directly below your crotch. Your feet should be directly under your knees. Push your hips up so that you form a straight line from your knees to your shoulders. Use a pad for comfort.',
        '"Hip Thrust" by Bret Contreras, wger.de, CC BY-SA 4.0'),
    'good_morning': ('Stand with your feet more than shoulder-width apart (wider stance) and place your hands on your hips. Hinge at your hips and lower your upper body towards the ground while keeping your back straight then come back up.',
        '"Good Morning" by captive0592, wger.de, CC BY-SA 4.0'),
    'sl_rdl': ("Stand upright and hold weights in both hands if using loads. Brace your core and lift one leg off the ground. Keep your back straight, hinge at the hips while lowering your torso forward, ensuring you don’t rotate your hips. Lower until you feel a stretch in your standing leg's hamstring, then return to standing position. Repeat on both sides.",
        '"Single Leg RDL" by captive0592, wger.de, CC BY-SA 4.0'),
    'superman': ('Lay flat on your stomach with your arms extended in front of you on the ground as your legs are lying flat. Lift both your arms and legs at the same time, as if you were flying, and contract the lower back. Make sure that you are breathing and, depending on your fitness level, hold the movement for at least two to five seconds per repetition.',
        '"Superman" by baldurmen, wger.de, CC BY-SA 4.0'),
    'reverse_lunge': ('Starting position: Stand straight, feet hip-width apart. Steps: Step backward with one leg so it can bend comfortably to a 90 degree angle. Slowly bend both knees to form 90 degree angles. Return to the starting position. Repeat, alternating legs.',
        '"Reverse lunges" by wger.de contributors, wger.de, CC BY-SA 4.0'),
    'walking_lunge': ('Starting Position: Stand with feet hip-width apart and hands either on your hips or holding dumbbells at your sides. The Stride: Take a wide step forward with your right leg. The Descent: Lower your hips until both knees are bent at approximately 90-degree angles. The Transition: Drive through your front heel to stand up, bringing your back foot forward to step directly into the next lunge.',
        '"Dumbbell Lunges Walking" by wger.de, wger.de, CC BY-SA 3.0'),
    'bulgarian_split_squat': ('Stand tall in front of a chair and take a large step. Put the upper part of one of your feet on the chair. Bend the front knee, balancing with arms until the back knee almost touches the ground. Push back to the starting position and repeat.',
        '"Bulgarian split squats left" by wger.de contributors, wger.de, CC BY-SA 4.0'),
    'step_up': ('Starting position: Stand facing a chair. Steps: Step up onto the chair. Step off the chair. Repeat.',
        '"Step-ups" by wger.de contributors, wger.de, CC BY-SA 4.0'),
    'lateral_lunge': ('Starting position: Stand tall and take a wide lateral stride, just greater than shoulder width. Steps: Bend one knee until your thigh is parallel to the floor. The bent knee must be in line with the foot. Push back to the starting position. Repeat.',
        '"Side split squats left" by wger.de contributors, wger.de, CC BY-SA 4.0'),
    'plank': ('Get into a position on the floor supporting your weight on your forearms and toes. Arms are bent and directly below the shoulder. Keep your body straight at all times and hold this position as long as possible. To increase difficulty an arm or leg can be raised while performing this exercise.',
        '"Plank" by YYCfit / BFad07, wger.de, CC BY-SA 3.0'),
    'side_plank': ('Starting position: Lie down on your side, with your bottom elbow at a right angle, arm sticking out. Lift your pelvis off the floor by lifting your bottom shoulder up, keeping the forearm on the floor; your head, pelvis, and feet should be in a straight line. Steps: Hold this position.',
        '"Side plank right" by wger.de contributors, wger.de, CC BY-SA 4.0'),
    'dead_bug': ('Lie on your back, with your hips and knees bent to 90°. Raise both arms toward the ceiling. Pull your lower back to the floor to eliminate the gap. Start by pressing one leg out, and tapping the heel to the floor. "As you extend one leg, exhale as much as you can, keeping your lower back glued to the floor," Dunham says. When you can’t exhale any more, pull your knee back to the starting position. Make this more difficult by holding weight in your hands, or by lowering opposite arm and leg.',
        '"Deadbug" by Metin, wger.de, CC BY-SA 4.0'),
    'hollow_hold': ('Get on a mat and lie on your back. Contract your abs, stretch your arms and legs and raise them (your head and shoulders are also be raised). Make sure your lower back remains in contact with the mat.',
        '"Hollow Hold" by Behrooz, wger.de, CC0'),
    'russian_twist': ("Hold a dumbbell, barbell weight or something else that is heavy with both hands, but make sure it is not too heavy and you are able to keep in form. Lean back to a 45-degree angle from the floor. For an extra challenge, lift your feet off the floor. Rotate your arms to one side to the same level as your chest, touch the floor for a little extra challenge, and then do the same to the other side. When you're back in your original position after doing both sides it will count as 1 rep.",
        '"Russian Twist" by lion, wger.de, CC BY-SA 4.0'),
    'bird_dog': ('Begin on all fours with hands under shoulders and knees under hips, keeping your spine neutral. Extend your right arm forward and left leg backward simultaneously, keeping hips square. Pause briefly at full extension while engaging your core and glutes. Return to the starting position and repeat on the opposite side',
        '"Bird Dog" by Settebello, wger.de, CC BY-SA 4.0 (excerpt)'),
    'mountain_climber': ('Starting position: Start in the upright push-up position, aka. the high plank position. Hands should be directly under your shoulders. Keep your head in line with your back, facing the floor. Feet should be about hip-width apart. Steps: Move one knee toward the center of your body, towards your elbows, keeping the other leg extended. In a quick jumping movement, straighten the bent leg out and pull the other knee toward your body. Keep repeating step 2, alternating legs. Notes: Throughout the exercise, your back should remain as straight as possible – avoid a hump or a sagging back.',
        '"Mountain climbers" by wger.de contributors, wger.de, CC BY-SA 4.0'),
    'farmer_carry': ('Grab half your body weight in each hand and walk.',
        '"Dumbbell farmer\'s carry" by philip, wger.de, CC BY-SA 4.0'),
    'suitcase_carry': ('Walk forward and backward with holding dumbbell on one side without leaning to counter the weight.',
        '"Suitcase Carry" by aboksz, wger.de, CC BY-SA 4.0'),
    'run': ('Get your shoes on, go outside and start running at a moderate pace.',
        '"Jogging" by Papazit, wger.de, CC BY-SA 4.0'),
    'jump_rope': ('Starting position: Put your feet close together, bend the knees a bit, keep your head and body straight, keep elbows in, open your arms. Steps: Spin only your wrists with enough force to make the rope spin. Jump just high enough to pass the rope below your feet. Repeat. Notes: This exercise requires a jump rope. Make sure the rope length is adjusted to your height. One way to check is to grab both handles with one hand and stand on the middle of the rope hanging on the ground with one foot. If the rope (excluding the handles) reaches just below your chest, its length is right. A shorter rope would be hazardous, as you might hit yourself, and a longer rope would make for bad form.',
        '"Jump rope: basic jumps" by wger.de contributors, wger.de, CC BY-SA 4.0'),
    'burpee': ('Starting position: Stand straight, feet hip-width apart. Steps: Squat low and support yourself on the floor with your hands between the knees and in front of your feet, your back straight. Keeping your hands on the floor, jump your legs backward into high plank position. Jump your feet forward to return to the squat position. Repeat.',
        '"4-count burpees" by wger.de contributors, wger.de, CC BY-SA 4.0'),
    'high_knees': ('Starting positionStand straight. Steps: Run in place, putting knees as high up as is comfortable and switching legs at a quick pace.',
        '"High knees" by wger.de contributors, wger.de, CC BY-SA 4.0'),
    'jumping_jacks': ('A jumping jack or star jump, also called side-straddle hop in the US military, is a physical jumping exercise performed by jumping to a position with the legs spread wide and the hands going overhead, sometimes in a clap, and then returning to a position with the feet together and the arms at the sides',
        '"Jumping Jacks" by student1234, wger.de, CC BY-SA 4.0'),
    'broad_jump': ('Stand with your feet shoulder-width apart. Swing your arms backwards while bending your knees and hips. Explosively extend your lower body and swing your arms forwards to jump as far as possible. Land on both feet with your knees bent, maintain balance and reset before the next repetition.',
        '"Standing Broad Jump" by AlejandroOS, wger.de, CC BY-SA 4.0'),
    'arm_circles': ('Starting position: Stand tall with your back straight. Steps: Keeping your arms straight, bring them in front of you, move them down, behind your back, then over your head, and back to the initial position. Keep circling your arms as described in step 1.',
        '"Forward arm circles" by wger.de contributors, wger.de, CC BY-SA 4.0'),
    'leg_swings': ('Stand tall next to a wall or stable support. Swing one leg forward and backward in a controlled motion, keeping the torso upright and the core engaged. Alternate legs after completing the repetitions.',
        '"Leg Swings (Front–Back)" by Jhonatan, wger.de, CC BY-SA 4.0'),
    'band_dislocate': ('Starting position: Stand up with your back straight and a resistance band, towel, or broomstick handle in hand. With your hands straight in front of your body and the band between your hands, push your hands apart to both be at around 45 degrees from your body, thumbs facing down. If using a towel or broomstick handle instead, grab it with an overhand grip. Steps: Keeping your arms outstretched, rotate at the shoulders to bring your arms overhead and then down toward your glutes. Rotate at the shoulders in the opposite direction — overhead and then toward your groin. Repeat.',
        '"Shoulder dislocates" by tinman, wger.de, CC BY-SA 4.0'),
    'cat_cow': ('First get into the four-footed stance. The hands are underneath the shoulders. The fingers are fanned out wide and ensure a stable stance. It is best to rest your front body weight on your thumbs and index fingers. Now place your legs hip-width apart on the yoga mat. Your thighs should be vertically below your hips. Make sure that your weight is evenly distributed between your hands and knees. Your head is an extension of your spine and you are looking down at your mat. Your back is in a neutral position. Breathe in deeply and start with the cat. With the next exhalation, round your back vertebra by vertebra. Try to pull yourself as far as possible towards the ceiling. Pull your head towards your chest and tilt your pelvis. Now inhale deeply and move into the opposite position, cow pose. Bend your back down, pull your shoulders back slightly and lift your head as far as is comfortable for you. Your gaze is directed upwards. Breathe out consciously and switch back to the cat. With the next exhalation, switch back to cow. Repeat the exercise a few times and make sure that you are in the flow.',
        '"Yoga exercise: Cow-cat" by damnlost, wger.de, CC BY-SA 4.0'),
    'hip_flexor_stretch': ('Kneel in a lunge position with one knee on the floor and the other foot in front, hands on your hips. Keep your torso upright, squeeze the glute of the back leg and push your hips forward until you feel a stretch at the front of the hip and thigh. Hold, then switch sides.',
        '"Hip Flexor Stretch" by Davidgj32, wger.de, CC BY-SA 4.0'),
    'hamstring_stretch': ('Sit on the floor with one leg extended straight in front of you, toes pointing up. Bend the other leg and rest the sole of that foot against the inner thigh of the straight leg, letting the knee fall out to the side. Sit up tall with your chest open and your shoulders back. Breathe in, then as you breathe out, lean forward from the hips over the straight leg while keeping your back long. Reach for your shin, ankle or foot, only as far as you can without rounding your back, and hold. Then switch sides.',
        '"Single Leg Hamstring Stretch" by captive0592, wger.de, CC BY-SA 4.0'),
    'childs_pose': ("Starting position: Start on all fours, knees, toes, and hands touching the ground. Your two big toes should be touching. Steps: Move your knees so that they're about hip-width apart. On an exhale, move your pelvis back to sit on your heels. Your hands should still be touching the ground. Relax your upper body, lowering your forehead to the floor and letting your hands move forward naturally. Stay in this pose. Tips: To leave the pose, walk your arms back under your shoulders and move your upper body up into a seated position.",
        '"Child\'s pose" by wger.de contributors, wger.de, CC BY-SA 4.0'),
    'front_squat': ('The starting position for the Front Squat is the Straddle Stance position with the toes pointed slightly outward. The bar is held across the top of the chest just below the collar bones using the crossed arms with pronated grip. From the starting position, bend the knees and slowly lower the body downward until there is a 90-degree angle between the upper and lower leg. Return to the starting position.',
        'U.S. Army ATP 7-22.02 (2020), public domain (excerpt)'),
    'bb_row': ('The starting position for the Bent-Over Row is the Forward Leaning Stance position with arms fully extended down and in front of the body holding the bar with an overhand grip in front of the legs. Position the arms slightly wider than shoulder width and keep the head in line with the spine. From the starting position, pull the weight toward the chest until the upper arms are parallel to the ground. Elbows should be up and pointing to the rear. Head and spine position remain in the starting position.',
        'U.S. Army ATP 7-22.02 (2020), public domain (excerpt)'),
    # Exercises with no openly licensed description were written for this app:
    'incline_push_up': ('Place your hands on a sturdy bench, box or table edge, slightly wider than shoulder-width. Walk your feet back until your body forms a straight line from head to heels. Keeping your core tight and elbows about 45 degrees from your sides, lower your chest to the edge. Press back up until your arms are straight. The higher the surface, the easier the push-up.',
        'Written for IronQuest (no licensed source found)'),
    'pike_push_up': ('Start in a push-up position, then walk your feet toward your hands and lift your hips high so your body forms an upside-down V. Keep your hands shoulder-width apart and your legs as straight as you can. Bend your elbows to lower the top of your head toward the floor just in front of your hands, keeping your hips high. Press back up to the start. Raise your feet on a bench to make it harder.',
        'Written for IronQuest (no licensed source found)'),
    'doorframe_row': ('Stand in an open doorway and grip both sides of a sturdy door frame at about chest height. Keep your feet close to the doorway and lean back until your arms are straight, holding your body in a straight line. Pull your chest toward the frame by bending your elbows and squeezing your shoulder blades together. Lower yourself slowly until your arms are straight again. Move your feet closer to the frame to make it harder. Check that your grip is secure before leaning back.',
        'Written for IronQuest (no licensed source found)'),
    'kb_goblet_squat': ('Hold a kettlebell by the sides of its handle (the horns) at chest height, elbows pointing down and close to your body. Stand with your feet slightly wider than shoulder-width, toes turned slightly out. Keeping your chest up and back straight, push your hips back and bend your knees to squat until your thighs are at least parallel to the floor, letting your elbows track inside your knees. Drive through your whole foot to stand back up.',
        'Written for IronQuest (no licensed source found)'),
    'jump_squat': ('Stand with your feet shoulder-width apart. Squat down by pushing your hips back and bending your knees until your thighs are about parallel to the floor, swinging your arms back. Explode upward, swinging your arms forward and jumping as high as you can. Land softly on the balls of your feet with your knees bent, and sink straight into the next squat.',
        'Written for IronQuest (no licensed source found)'),
    'hanging_knee_raise': ('Hang from a pull-up bar with an overhand grip, hands about shoulder-width apart and arms straight. Brace your core and pull your shoulders down away from your ears. Without swinging, bend your knees and raise them toward your chest until your thighs are at least parallel to the floor, curling your pelvis up slightly at the top. Lower your legs slowly back to the hang. If you start swinging, pause at the bottom until you are still.',
        'Written for IronQuest (no licensed source found)'),
    'ruck_march': ('Load a rucksack with a weight you can carry comfortably (start around 10-15% of your bodyweight) and wear well-fitting boots or shoes and good socks. Tighten the shoulder straps and hip belt so the load sits high and close to your back. Walk at a steady, brisk pace (about 15 minutes per mile is a common goal), standing tall instead of leaning forward. Drink water along the way, and add distance or weight gradually from week to week to avoid blisters and injuries.',
        'Written for IronQuest (no licensed source found)'),
    'sprint_intervals': ('Warm up with 5-10 minutes of easy jogging. Then run at near-maximum effort for a short burst of about 15-30 seconds (or 100 meters), staying tall and driving your arms. Recover by walking or jogging slowly for 1-2 minutes, until your breathing settles. Repeat for the planned time, then finish with an easy jog to cool down. Stop when your sprinting form starts to break down.',
        'Written for IronQuest (no licensed source found)'),
    'skater_hops': ('Stand on your right foot with a slight bend in the knee. Push off and leap sideways to the left, landing softly on your left foot. Let your right leg swing behind your left ankle without touching down, and swing your right arm across your body like a speed skater. Pause briefly to balance, then leap back to the right. Keep alternating at a steady rhythm.',
        'Written for IronQuest (no licensed source found)'),
    'worlds_greatest': ('From standing, step your right foot forward into a deep lunge and lower your back knee toward the floor. Place your left hand on the floor inside your right foot. Drop your right elbow toward the inside of your right ankle, then rotate your chest open and reach your right arm toward the ceiling, following your hand with your eyes. Return your hand to the floor, step back to standing, and repeat on the other side.',
        'Written for IronQuest (no licensed source found)'),
    'inchworm': ('Stand tall with your feet hip-width apart. Hinge at the hips and bend forward to place your hands on the floor in front of your feet, bending your knees only as much as you need to. Walk your hands forward one at a time until you are in a high plank with your shoulders over your wrists. Then walk your feet up toward your hands, keeping your legs as straight as is comfortable. Stand up and repeat.',
        'Written for IronQuest (no licensed source found)'),
    'chest_opener': ("Stand tall and interlace your fingers behind your back (hold a towel or band between your hands if they don't reach). Squeeze your shoulder blades together and gently straighten your arms, lifting your hands away from your lower back. Lift your chest and keep your chin level, without arching your lower back. Hold the stretch while breathing slowly, then release.",
        'Written for IronQuest (no licensed source found)'),
}
NO_GUIDE = "No verified how-to guide was found for this exercise yet."

for _e in DEFAULT_EXERCISES:
    _e["how_to"], _e["how_to_source"] = HOW_TO.get(_e["id"], ("", ""))


# =====================================================================
#  SMALL HELPERS
# =====================================================================

def now():
    return dt.datetime.now().replace(microsecond=0)


def iso(when):
    return when.replace(microsecond=0).isoformat()


def parse_iso(text, fallback=None):
    try:
        return dt.datetime.fromisoformat(str(text))
    except (TypeError, ValueError):
        return fallback


def week_key(when):
    year, week, _ = when.isocalendar()
    return f"{year}-W{week:02d}"


def fmt_num(value):
    """10.0 -> '10', 12.5 -> '12.5'."""
    value = float(value)
    return str(int(value)) if value.is_integer() else f"{value:.1f}".rstrip("0").rstrip(".")


def to_lb(value, units):
    return float(value) * LB_PER_KG if units == "kg" else float(value)


def from_lb(value_lb, units):
    return float(value_lb) / LB_PER_KG if units == "kg" else float(value_lb)


def round_weight(value_lb, units):
    """Round a load to a plate-friendly step (5 lb or 2.5 kg); returns lb."""
    if units == "kg":
        kg = round(value_lb / LB_PER_KG / 2.5) * 2.5
        return kg * LB_PER_KG
    return float(round(value_lb / 5) * 5)


def display_weight(value_lb, units):
    return fmt_num(round(from_lb(value_lb, units) * 2) / 2)


def fmt_minutes(minutes):
    secs = int(round(float(minutes) * 60))
    if secs < 60:
        return f"{secs}s"
    m, s = divmod(secs, 60)
    return f"{m}:{s:02d}" if s else f"{m} min"


# =====================================================================
#  INPUT VALIDATION
# =====================================================================

class ValidationError(ValueError):
    """Raised when user input is invalid. The message is shown to the user."""


def parse_int(text, lo, hi, label):
    text = str(text).strip()
    if text == "":
        raise ValidationError(f"{label} is required.")
    try:
        value = int(text)
    except ValueError:
        raise ValidationError(f"{label} must be a whole number.") from None
    if not lo <= value <= hi:
        raise ValidationError(f"{label} must be between {lo} and {hi}.")
    return value


def parse_float(text, lo, hi, label):
    text = str(text).strip()
    if text == "":
        raise ValidationError(f"{label} is required.")
    try:
        value = float(text)
    except ValueError:
        raise ValidationError(f"{label} must be a number.") from None
    if math.isnan(value) or math.isinf(value):
        raise ValidationError(f"{label} must be a number.")
    if not lo <= value <= hi:
        raise ValidationError(
            f"{label} must be between {fmt_num(lo)} and {fmt_num(hi)}.")
    return value


def parse_mmss(text, lo_s, hi_s, label):
    text = str(text).strip()
    match = re.fullmatch(r"(\d{1,2}):([0-5]\d)", text)
    if not match:
        raise ValidationError(f"{label} must be in mm:ss format (e.g. 8:30).")
    seconds = int(match.group(1)) * 60 + int(match.group(2))
    if not lo_s <= seconds <= hi_s:
        raise ValidationError(
            f"{label} must be between {lo_s // 60}:{lo_s % 60:02d} "
            f"and {hi_s // 60}:{hi_s % 60:02d}.")
    return seconds


def validate_description(text):
    """Clean an optional how-to description for a custom exercise."""
    lines = [" ".join(line.split()) for line in str(text).splitlines()]
    cleaned = re.sub(r"\n{3,}", "\n\n", "\n".join(lines)).strip()
    if not cleaned:
        return ""
    if len(cleaned) < DESC_MIN:
        raise ValidationError(f"Description is too short (at least {DESC_MIN} characters), "
                              "or leave it blank.")
    if len(cleaned) > DESC_MAX:
        raise ValidationError(f"Description is too long ({len(cleaned)} of {DESC_MAX} characters).")
    return cleaned


def validate_name(text, max_len, label):
    text = str(text).strip()
    if not text:
        raise ValidationError(f"{label} cannot be blank.")
    if len(text) > max_len:
        raise ValidationError(f"{label} must be {max_len} characters or fewer.")
    return text


def weight_range(units):
    return WEIGHT_RANGE_KG if units == "kg" else WEIGHT_RANGE_LB


def bodyweight_range(units):
    return BODYWEIGHT_RANGE_KG if units == "kg" else BODYWEIGHT_RANGE_LB


# =====================================================================
#  DATA STORE  (load at startup, save after changes and before closing)
# =====================================================================

def normalize_exercise(raw):
    """Return a cleaned exercise dict, or None if the record is unusable."""
    if not isinstance(raw, dict):
        return None
    try:
        ex = {
            "id": str(raw["id"]).strip(),
            "name": str(raw["name"]).strip(),
            "pattern": raw["pattern"],
            "category": raw["category"],
            "primary": [m for m in raw.get("primary", []) if m in MUSCLES],
            "secondary": [m for m in raw.get("secondary", []) if m in MUSCLES],
            "equipment": [e for e in raw.get("equipment", []) if e in EQUIPMENT],
            "difficulty": int(raw.get("difficulty", 1)),
            "stat": raw.get("stat", "STR"),
            "kind": raw.get("kind", "reps"),
            "bw_factor": float(raw.get("bw_factor", 0)),
            "default": dict(raw.get("default", {})),
            "start_pct": float(raw.get("start_pct", 0)),
            "per_hand": bool(raw.get("per_hand", False)),
            "role": str(raw.get("role", "")),
            "custom": bool(raw.get("custom", False)),
            "how_to": str(raw.get("how_to") or "")[:3000],
            "how_to_source": str(raw.get("how_to_source") or "")[:300],
        }
    except (KeyError, TypeError, ValueError):
        return None
    if (not ex["id"] or not ex["name"] or ex["pattern"] not in PATTERNS
            or ex["category"] not in CATEGORIES or ex["kind"] not in ("reps", "timed")
            or ex["stat"] not in STATS or not ex["primary"]
            or ex["difficulty"] not in DIFF_MULT):
        return None
    d = ex["default"]
    try:
        d["sets"] = max(1, min(10, int(d.get("sets", 3))))
        if ex["kind"] == "reps":
            d["reps"] = max(1, min(100, int(d.get("reps", 10))))
            d.pop("minutes", None)
        else:
            d["minutes"] = max(0.25, min(180, float(d.get("minutes", 1))))
            d.pop("reps", None)
    except (TypeError, ValueError):
        return None
    return ex


def _safe_num(value, default=0.0, lo=None, hi=None):
    """Finite float or default; optionally clamped."""
    try:
        v = float(value)
    except (TypeError, ValueError):
        return default
    if not math.isfinite(v):
        return default
    if lo is not None:
        v = max(lo, v)
    if hi is not None:
        v = min(hi, v)
    return v


def _safe_int(value, default=0, lo=0):
    return int(_safe_num(value, default, lo))


def normalize_workout(raw):
    """Clean one history record, or None if it is unusable."""
    if (not isinstance(raw, dict) or parse_iso(raw.get("date")) is None
            or not isinstance(raw.get("exercises"), list)):
        return None
    w = dict(raw)
    w["name"] = str(raw.get("name") or "Quest")[:40]
    w["focus"] = str(raw.get("focus") or "Custom")[:20]
    w["xp"] = _safe_int(raw.get("xp"))
    w["duration_min"] = _safe_int(raw.get("duration_min"))
    prs = raw.get("prs")
    w["prs"] = [str(x) for x in prs if isinstance(x, str)] if isinstance(prs, list) else []
    exercises = []
    for e in raw["exercises"]:
        if not isinstance(e, dict) or not isinstance(e.get("sets"), list):
            continue
        e = dict(e)
        e["ex_id"] = str(e.get("ex_id") or "")
        e["name"] = str(e.get("name") or e["ex_id"] or "Exercise")[:40]
        e["pattern"] = e.get("pattern") if e.get("pattern") in PATTERNS else "core"
        e["category"] = e.get("category") if e.get("category") in CATEGORIES else "accessory"
        e["kind"] = e.get("kind") if e.get("kind") in ("reps", "timed") else "reps"
        e["per_hand"] = bool(e.get("per_hand", False))
        e["xp"] = _safe_num(e.get("xp"), 0.0, 0)
        sets = []
        for st in e["sets"]:
            if not isinstance(st, dict):
                continue
            sets.append({"target": st.get("target"),
                         "reps": _safe_int(st.get("reps")),
                         "weight_lb": _safe_num(st.get("weight_lb"), 0.0, 0, 2000),
                         "minutes": _safe_num(st.get("minutes"), 0.0, 0, 600),
                         "effort": st.get("effort") if st.get("effort") in EFFORTS else "moderate"})
        e["sets"] = sets
        exercises.append(e)
    w["exercises"] = exercises
    w["sets_done"] = _safe_int(raw.get("sets_done"), sum(len(e["sets"]) for e in exercises))
    return w


BOSS_KEYS = {"week": str, "name": str, "flavor": str, "max_hp": (int, float),
             "hp": (int, float), "defeated": bool}
RECORD_TYPES = {"minutes": 0, "reps": 1, "e1rm": 2}    # priority when types differ


def hero_template():
    stamp = iso(now())
    return {
        "version": 1, "name": "Hero", "bodyweight_lb": 170.0, "units": "lb",
        "equipment": [], "goal": "General", "days_per_week": 3,
        "training_level": 1, "baseline": {}, "created": stamp,
        "total_xp": 0, "stat_xp": {s: 0.0 for s in STATS},
        "base_stats": {s: 5 for s in STATS},
        "fatigue": {m: 0.0 for m in MUSCLES}, "fatigue_updated": stamp,
        "records": {}, "prs_broken": 0, "best_streak": 0,
        "boss": None, "bosses_defeated": 0, "titles": [],
        "quests": {"week": "", "list": []}, "achievements": {},
        "active_session": None, "appearance": "Dark",
    }


def normalize_hero(raw):
    """Merge a loaded hero with the template so missing/bad fields are repaired."""
    hero = hero_template()
    if not isinstance(raw, dict):
        return None
    for key, value in raw.items():
        if key in hero:
            hero[key] = value
    # Nested numeric dicts: keep only valid, finite numbers.
    for key, keys, default in (("stat_xp", STATS, 0.0), ("base_stats", STATS, 5),
                               ("fatigue", MUSCLES, 0.0)):
        src = raw.get(key) if isinstance(raw.get(key), dict) else {}
        hi = 100.0 if key == "fatigue" else 1e7
        hero[key] = {k: _safe_num(src.get(k, default), default, 0.0, hi) for k in keys}
    hero["name"] = str(hero["name"] or "Hero").strip()[:NAME_MAX] or "Hero"
    for key in ("prs_broken", "bosses_defeated", "best_streak"):
        hero[key] = _safe_int(hero.get(key))
    try:
        hero["bodyweight_lb"] = float(hero["bodyweight_lb"])
    except (TypeError, ValueError):
        hero["bodyweight_lb"] = 170.0
    if not BODYWEIGHT_RANGE_LB[0] <= hero["bodyweight_lb"] <= BODYWEIGHT_RANGE_LB[1]:
        hero["bodyweight_lb"] = 170.0
    if hero["units"] not in ("lb", "kg"):
        hero["units"] = "lb"
    if hero["goal"] not in GOALS:
        hero["goal"] = "General"
    try:
        hero["training_level"] = min(3, max(1, int(hero["training_level"])))
        hero["days_per_week"] = min(6, max(2, int(hero["days_per_week"])))
        hero["total_xp"] = max(0, int(hero["total_xp"]))
    except (TypeError, ValueError):
        hero["training_level"], hero["days_per_week"], hero["total_xp"] = 1, 3, 0
    if not isinstance(hero["equipment"], list):
        hero["equipment"] = []
    hero["equipment"] = [e for e in hero["equipment"] if e in EQUIPMENT]
    for key in ("records", "achievements", "baseline"):
        if not isinstance(hero[key], dict):
            hero[key] = {}
    hero["records"] = {k: r for k, r in hero["records"].items()
                       if isinstance(r, dict) and r.get("type") in RECORD_TYPES
                       and math.isfinite(_safe_num(r.get("value"), float("nan")))}
    hero["baseline"] = {k: _safe_int(v) for k, v in hero["baseline"].items()
                        if k in BASELINE_TESTS and isinstance(v, (int, float))
                        and BASELINE_TESTS[k]["lo"] <= v <= BASELINE_TESTS[k]["hi"]}
    hero["achievements"] = {str(k): str(v) for k, v in hero["achievements"].items()}
    quests = hero["quests"] if isinstance(hero["quests"], dict) else {}
    qlist = quests.get("list") if isinstance(quests.get("list"), list) else []
    if not all(isinstance(q, dict) and q.get("id") in QUEST_POOL
               and isinstance(q.get("n"), (int, float)) and isinstance(q.get("reward"), int)
               for q in qlist):
        qlist = []
    hero["quests"] = {"week": str(quests.get("week", "")) if qlist else "", "list": qlist}
    if not isinstance(hero["titles"], list):
        hero["titles"] = []
    hero["titles"] = [str(t) for t in hero["titles"]]
    boss = hero["boss"]
    if boss is not None and not (isinstance(boss, dict) and all(
            isinstance(boss.get(k), t) for k, t in BOSS_KEYS.items())):
        hero["boss"] = None
    elif boss is not None:
        boss["max_hp"] = max(1, _safe_int(boss["max_hp"], 1))
        boss["hp"] = min(boss["max_hp"], _safe_int(boss["hp"]))
    if hero["active_session"] is not None and not isinstance(hero["active_session"], dict):
        hero["active_session"] = None
    if hero["appearance"] not in ("Dark", "Light"):
        hero["appearance"] = "Dark"
    return hero


STORE_KEYS = ("exercises", "hero", "workouts")
STORE_FILES = {"exercises": EXERCISES_FILE, "hero": HERO_FILE, "workouts": WORKOUTS_FILE}


class FileBackend:
    """Keeps the three data sets as JSON files in a folder (desktop, Android, iOS app)."""

    def __init__(self, base_dir):
        os.makedirs(base_dir, exist_ok=True)
        self.base_dir = base_dir
        self.paths = {k: os.path.join(base_dir, f) for k, f in STORE_FILES.items()}

    def read(self, key):
        """Return (text or None if missing)."""
        path = self.paths[key]
        if not os.path.exists(path):
            return None
        with open(path, "r", encoding="utf-8") as f:
            return f.read()

    def write(self, key, text):
        """Atomic write: dump to a temp file, then replace the real file."""
        path = self.paths[key]
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(text)
        os.replace(tmp, path)

    def backup(self, key):
        shutil.copyfile(self.paths[key], self.paths[key] + ".bak")

    def remove(self, key):
        if os.path.exists(self.paths[key]):
            os.remove(self.paths[key])


class MemoryBackend:
    """Keeps the data sets as JSON text in a dict - used by the web version.

    The web app loads the texts from the browser's storage at startup and
    passes on_change(key, text_or_None) to copy every change back there.
    """

    def __init__(self, texts=None, on_change=None):
        self.base_dir = "browser storage"
        self.texts = dict(texts or {})
        self.on_change = on_change

    def read(self, key):
        return self.texts.get(key)

    def _set(self, key, text):
        if self.texts.get(key) == text:
            return                      # unchanged: skip the trip to browser storage
        if text is None:
            self.texts.pop(key, None)
        else:
            self.texts[key] = text
        if self.on_change:
            self.on_change(key, text)

    def write(self, key, text):
        self._set(key, text)

    def backup(self, key):
        if self.texts.get(key) is not None:
            self._set(key + ".bak", self.texts[key])

    def remove(self, key):
        self._set(key, None)


class DataStore:
    """Owns the three data sets. Never crashes on missing or damaged data.

    By default they are JSON files in base_dir (or BASE_DIR); pass a
    backend (e.g. MemoryBackend) to keep them somewhere else.
    """

    def __init__(self, base_dir=None, backend=None):
        self.backend = backend or FileBackend(base_dir or BASE_DIR)
        self.base_dir = self.backend.base_dir
        self.paths = {k: os.path.join(self.base_dir, f) for k, f in STORE_FILES.items()}
        self.exercises = []
        self.hero = None
        self.workouts = []
        self.warnings = []

    # ---------- loading ----------
    def load(self):
        self.warnings = []
        self.exercises = self._load_exercises()
        self.hero = self._load_hero()
        self.workouts = self._load_workouts()

    def _read(self, key):
        try:
            text = self.backend.read(key)
            if text is None:
                return None, "missing"
            return json.loads(text), "ok"
        except (json.JSONDecodeError, UnicodeDecodeError, OSError):
            return None, "corrupt"

    def _quarantine(self, key, extra=""):
        name = STORE_FILES[key]
        try:
            self.backend.backup(key)
        except OSError:
            pass
        self.warnings.append(
            f"{name} was damaged and could not be read. "
            f"A copy was saved as {name}.bak. {extra}".strip())

    def _load_exercises(self):
        data, status = self._read("exercises")
        if status == "ok" and isinstance(data, list):
            clean, seen = [], set()
            for raw in data:
                ex = normalize_exercise(raw)
                if ex and ex["id"] not in seen:
                    clean.append(ex)
                    seen.add(ex["id"])
            for ex in clean:
                if not ex["custom"] and ex["id"] in HOW_TO:
                    ex["how_to"], ex["how_to_source"] = HOW_TO[ex["id"]]
            skipped = len(data) - len(clean)
            if clean:
                if skipped:
                    self.warnings.append(
                        f"{skipped} invalid exercise record(s) in "
                        f"{EXERCISES_FILE} were skipped.")
                return clean
        if status in ("ok", "corrupt"):
            self._quarantine("exercises", "The default exercise library was restored.")
        exercises = copy.deepcopy(DEFAULT_EXERCISES)
        self._write("exercises", exercises)
        return exercises

    def _load_hero(self):
        data, status = self._read("hero")
        if status == "missing":
            return None
        hero = normalize_hero(data) if status == "ok" else None
        if hero is None:
            self._quarantine("hero", "You'll need to create a new hero.")
        return hero

    def _load_workouts(self):
        data, status = self._read("workouts")
        if status == "ok" and isinstance(data, list):
            clean = [w for w in (normalize_workout(x) for x in data) if w is not None]
            if len(clean) < len(data):
                self.warnings.append(
                    f"{len(data) - len(clean)} invalid workout record(s) were skipped.")
            clean.sort(key=lambda w: w["date"])
            return clean
        if status != "missing":
            self._quarantine("workouts", "Workout history was reset.")
        self._write("workouts", [])
        return []

    # ---------- saving ----------
    def _write(self, key, data):
        try:
            self.backend.write(key, json.dumps(data, indent=2))
            return True
        except OSError as err:
            self.warnings.append(f"Could not save {STORE_FILES[key]}: {err}")
            return False

    def save_all(self):
        ok = self._write("exercises", self.exercises)
        ok = self._write("workouts", self.workouts) and ok
        if self.hero is not None:
            ok = self._write("hero", self.hero) and ok
        return ok

    def reset_hero(self):
        """Delete the hero and history (New Hero). The exercise library stays."""
        self.hero = None
        self.workouts = []
        try:
            self.backend.remove("hero")
        except OSError:
            pass
        self._write("workouts", [])

    @property
    def ex_map(self):
        return {e["id"]: e for e in self.exercises}


# =====================================================================
#  HERO CREATION & BASELINE
# =====================================================================

def baseline_score(key, value):
    test = BASELINE_TESTS[key]
    if test.get("lower_better"):
        if value <= test["adv"]:
            return 3
        return 1 if value >= test["beg"] else 2
    if value >= test["adv"]:
        return 3
    return 1 if value < test["beg"] else 2


def training_level_from_baseline(baseline):
    scores = [baseline_score(k, v) for k, v in baseline.items() if k in BASELINE_TESTS]
    if not scores:
        return 1
    avg = sum(scores) / len(scores)
    if avg < 1.7:
        return 1
    return 2 if avg < 2.4 else 3


def create_hero(name, bodyweight_lb, units, equipment, goal, days, baseline):
    hero = hero_template()
    hero.update({
        "name": name, "bodyweight_lb": float(bodyweight_lb), "units": units,
        "equipment": [e for e in equipment if e in EQUIPMENT], "goal": goal,
        "days_per_week": int(days), "baseline": dict(baseline),
        "training_level": training_level_from_baseline(baseline),
    })
    hero["base_stats"][GOALS[goal]] += 2
    return hero


# =====================================================================
#  FATIGUE / RECOVERY
# =====================================================================

def fatigue_now(hero, when=None):
    """Return decayed fatigue values without changing the hero."""
    when = when or now()
    last = parse_iso(hero.get("fatigue_updated"), when)
    hours = max(0.0, (when - last).total_seconds() / 3600)
    factor = 0.5 ** (hours / FATIGUE_HALF_LIFE_H)
    return {m: hero["fatigue"].get(m, 0.0) * factor for m in MUSCLES}


def decay_fatigue(hero, when=None):
    when = when or now()
    hero["fatigue"] = {m: round(v, 2) for m, v in fatigue_now(hero, when).items()}
    hero["fatigue_updated"] = iso(when)


def apply_set_fatigue(hero, ex, s):
    if ex["category"] == "mobility":
        return
    load = 1.0
    if ex["kind"] == "timed":
        load = min(1 + float(s.get("minutes", 0)) / 10, 3.0)
    for m in ex["primary"]:
        hero["fatigue"][m] = min(100.0, hero["fatigue"].get(m, 0) + FATIGUE_PRIMARY * load)
    for m in ex["secondary"]:
        hero["fatigue"][m] = min(100.0, hero["fatigue"].get(m, 0) + FATIGUE_SECONDARY * load)


# =====================================================================
#  XP, LEVELS, STATS, CLASS, STREAK
# =====================================================================

def set_xp(ex, s, bodyweight_lb):
    """XP for one completed set (design plan section 4)."""
    type_mult = TYPE_MULT.get(ex["category"], 1.0)
    if ex["kind"] == "timed":
        minutes = float(s.get("minutes") or 0)
        if minutes <= 0:
            return 0.0
        return 6 * type_mult * minutes ** 0.85 * EFFORT_MULT.get(s.get("effort"), 1.0)
    reps = int(s.get("reps") or 0)
    if reps <= 0:
        return 0.0
    weight = float(s.get("weight_lb") or 0) * (2 if ex.get("per_hand") else 1)
    effective = weight + ex.get("bw_factor", 0) * bodyweight_lb
    relative = effective / bodyweight_lb
    return type_mult * reps ** 0.8 * (1 + relative) * DIFF_MULT.get(ex["difficulty"], 1.0)


def record_of(ex, s, units="lb"):
    """(type, value, display) used for personal-record tracking."""
    if ex["kind"] == "timed":
        minutes = float(s.get("minutes") or 0)
        return "minutes", minutes, fmt_minutes(minutes)
    reps = int(s.get("reps") or 0)
    weight = float(s.get("weight_lb") or 0)
    if weight > 0:
        e1rm = weight * (1 + reps / 30)            # Epley estimated 1-rep max
        return "e1rm", round(e1rm, 1), f"{display_weight(weight, units)} {units} x {reps}"
    return "reps", reps, f"{reps} reps"


def record_text(rec, units):
    """Display a stored personal record in the hero's current units."""
    if rec.get("type") == "e1rm" and rec.get("weight_lb"):
        return f"{display_weight(rec['weight_lb'], units)} {units} x {rec.get('reps', 0)}"
    return rec.get("display", "")


def xp_needed(level):
    return int(round(80 * level ** 1.5))


def level_info(total_xp):
    """Return (level, xp into current level, xp needed for next level)."""
    level, remaining = 1, int(total_xp)
    while remaining >= xp_needed(level):
        remaining -= xp_needed(level)
        level += 1
    return level, remaining, xp_needed(level)


def stat_points(hero):
    return {s: int(hero["base_stats"].get(s, 5) + hero["stat_xp"].get(s, 0) // STAT_XP_PER_POINT)
            for s in STATS}


def hero_class(hero):
    """Return (class name, description, stat key)."""
    pts = stat_points(hero)
    top = max(STATS, key=lambda s: pts[s])
    hi, lo = max(pts.values()), min(pts.values())
    if sum(hero["stat_xp"].values()) > 0 and hi - lo <= 0.10 * hi:
        return CLASSES["ALL"][0], CLASSES["ALL"][1], "ALL"
    return CLASSES[top][0], CLASSES[top][1], top


def current_streak(workouts, when=None):
    when = when or now()
    days = sorted({parse_iso(w["date"]).date() for w in workouts
                   if parse_iso(w.get("date"))}, reverse=True)
    if not days or (when.date() - days[0]).days > STREAK_GAP_DAYS:
        return 0
    streak = 1
    for newer, older in zip(days, days[1:]):
        if (newer - older).days <= STREAK_GAP_DAYS:
            streak += 1
        else:
            break
    return streak


def lifetime_totals(workouts):
    volume, cardio = 0.0, 0.0
    for w in workouts:
        for e in w.get("exercises", []):
            for s in e.get("sets", []):
                if e.get("kind") == "timed":
                    if e.get("pattern") == "cardio":
                        cardio += float(s.get("minutes") or 0)
                else:
                    mult = 2 if e.get("per_hand") else 1
                    volume += float(s.get("weight_lb") or 0) * int(s.get("reps") or 0) * mult
    return {"workouts": len(workouts), "volume_lb": volume, "cardio_min": cardio}


# =====================================================================
#  BOSS, QUESTS, ACHIEVEMENTS
# =====================================================================

def boss_hp(level, days):
    return int(round((600 + 80 * level) * days / 4))


def roll_quests(hero, key):
    rng = random.Random(f"{key}-{hero['name']}")
    others = rng.sample([q for q in QUEST_POOL if q != "train_days"], 2)
    quests = [{"id": "train_days", "n": hero["days_per_week"],
               "reward": QUEST_POOL["train_days"][1], "done": False}]
    for qid in others:
        quests.append({"id": qid, "n": QUEST_TARGETS[qid],
                       "reward": QUEST_POOL[qid][1], "done": False})
    return quests


def quest_text(q):
    return QUEST_POOL[q["id"]][0].format(n=q["n"])


def ensure_week(hero, when=None):
    """Spawn this week's boss and quests if a new week has started."""
    when = when or now()
    key = week_key(when)
    changed = False
    boss = hero.get("boss")
    if not boss or boss.get("week") != key:
        level = level_info(hero["total_xp"])[0]
        year, week, _ = when.isocalendar()
        name, flavor = BOSSES[(year * 53 + week) % len(BOSSES)]
        hp = boss_hp(level, hero["days_per_week"])
        hero["boss"] = {"week": key, "name": name, "flavor": flavor,
                        "max_hp": hp, "hp": hp, "defeated": False,
                        "defeated_on": None}
        changed = True
    quests = hero.get("quests") or {}
    if quests.get("week") != key or not quests.get("list"):
        hero["quests"] = {"week": key, "list": roll_quests(hero, key)}
        changed = True
    return changed


def week_workouts(workouts, when=None):
    key = week_key(when or now())
    return [w for w in workouts if parse_iso(w.get("date"))
            and week_key(parse_iso(w["date"])) == key]


def quest_progress(q, week_ws):
    qid = q["id"]
    if qid == "train_days":
        return len({parse_iso(w["date"]).date() for w in week_ws})
    if qid == "set_pr":
        return sum(len(w.get("prs", [])) for w in week_ws)
    if qid == "earn_xp":
        return sum(int(w.get("xp", 0)) for w in week_ws)
    if qid == "balanced":
        return sum(1 for w in week_ws
                   if len({e.get("pattern") for e in w.get("exercises", [])} - {"mobility"}) >= 4)
    total = 0
    for w in week_ws:
        for e in w.get("exercises", []):
            n_sets = len(e.get("sets", []))
            pattern = e.get("pattern")
            if qid == "pull_sets" and pattern == "pull":
                total += n_sets
            elif qid == "push_sets" and pattern == "push":
                total += n_sets
            elif qid == "lower_sets" and pattern in LOWER_PATTERNS:
                total += n_sets
            elif qid == "core_sets" and (pattern == "core" or e.get("category") == "core"):
                total += n_sets
            elif qid == "cardio_min" and pattern == "cardio" and e.get("kind") == "timed":
                total += sum(float(s.get("minutes") or 0) for s in e.get("sets", []))
    return int(total)


def check_achievements(hero, workouts, when=None):
    """Unlock any newly earned achievements. Returns a list of their names."""
    when = when or now()
    totals = lifetime_totals(workouts)
    level = level_info(hero["total_xp"])[0]
    pts = stat_points(hero)
    earned = {
        "first_workout": totals["workouts"] >= 1,
        "workouts_10": totals["workouts"] >= 10,
        "workouts_25": totals["workouts"] >= 25,
        "level_5": level >= 5, "level_10": level >= 10, "level_20": level >= 20,
        "boss_1": hero["bosses_defeated"] >= 1, "boss_5": hero["bosses_defeated"] >= 5,
        "pr_5": hero["prs_broken"] >= 5,
        "streak_5": hero["best_streak"] >= 5,
        "ten_ton": totals["volume_lb"] >= 20000,
        "road_warrior": totals["cardio_min"] >= 300,
        "well_rounded": min(pts.values()) >= 15,
    }
    new = []
    for aid, name, _desc in ACHIEVEMENTS:
        if earned.get(aid) and aid not in hero["achievements"]:
            hero["achievements"][aid] = iso(when)
            new.append(name)
    return new


# =====================================================================
#  WORKOUT GENERATOR
# =====================================================================

def uses_weight(ex):
    return ex["kind"] == "reps" and bool(set(ex["equipment"]) & WEIGHTED_EQUIPMENT)


def is_available(ex, equipment):
    return set(ex["equipment"]) <= set(equipment)


def is_long_cardio(ex):
    return ex["kind"] == "timed" and ex["default"].get("minutes", 0) > 5


def last_performance(ex_id, workouts):
    for w in reversed(workouts):
        for e in w.get("exercises", []):
            if e.get("ex_id") == ex_id and e.get("sets"):
                return e
    return None


def suggest_weight(ex, hero, workouts):
    """Suggested load in lb: progressive overload from history, else % of bodyweight."""
    if not uses_weight(ex):
        return 0.0
    units = hero["units"]
    last = last_performance(ex["id"], workouts)
    if last:
        loaded = [s for s in last["sets"] if float(s.get("weight_lb") or 0) > 0]
        if loaded:
            top = max(float(s["weight_lb"]) for s in loaded)
            hit_all = all(int(s.get("reps") or 0) >= int(s.get("target") or s.get("reps") or 0)
                          for s in last["sets"])
            step = 2.5 * LB_PER_KG if units == "kg" else 5.0
            return round_weight(top + step, units) if hit_all else round_weight(top, units)
    pct = ex.get("start_pct", 0)
    if pct <= 0:
        return 0.0
    load = pct * hero["bodyweight_lb"] * LEVEL_LOAD[hero["training_level"]]
    minimum = 2.5 * LB_PER_KG if units == "kg" else 5.0
    return max(minimum, round_weight(load, units))


def prescribe(ex, slot_code, focus, level, hero, workouts, phase):
    """Return a plan item for an exercise: sets, reps/minutes, weight, rest."""
    d = ex["default"]
    item = {"ex_id": ex["id"], "phase": phase, "reps": None, "minutes": None,
            "weight_lb": 0.0}
    if phase in ("warmup", "cooldown"):
        item.update(sets=1, rest=0, reps=d.get("reps"), minutes=d.get("minutes"))
        return item
    scheme = SCHEMES.get(focus, SCHEMES["Full Body"])
    key = "C" if (slot_code == "C" and ex["category"] == "compound") else "A"
    sets, reps, rest = scheme[key]
    if ex["category"] == "core" or phase == "finisher":
        sets, rest = d["sets"], 45
    if level == 1:
        sets = min(sets, 3)
    if is_long_cardio(ex):
        item.update(sets=1, rest=0, minutes=d["minutes"])
        return item
    if ex["kind"] == "timed":
        minutes = d["minutes"]
        if focus == "Conditioning":
            minutes = min(minutes, 0.75)
        item.update(sets=sets, rest=rest, minutes=minutes)
        return item
    if not uses_weight(ex):
        reps = max(3, int(round(d.get("reps", 10) * LEVEL_REPS[level])))
    item.update(sets=sets, rest=rest, reps=reps,
                weight_lb=suggest_weight(ex, hero, workouts))
    return item


def item_minutes(ex, item):
    if ex["kind"] == "timed":
        work = float(item["minutes"] or 1) * 60
    else:
        work = int(item["reps"] or 10) * 3
    return item["sets"] * (work + item["rest"]) / 60 + 0.5


def _score(ex, code, used_patterns, last_ids, fatigue, level, rng):
    score = 0.0
    cat = ex["category"]
    if code == "C":
        score += 3 if cat == "compound" else 0
    elif code == "A":
        score += 2 if cat == "accessory" else (1 if cat == "compound" else 0)
    elif code == "X":
        score += 3 if cat == "cardio" else 0
    elif code == "K":
        score += 3 if cat == "core" else 0
    else:
        score += 1
    prim = [fatigue.get(m, 0) for m in ex["primary"]] or [0]
    score += 2 * (1 - (sum(prim) / len(prim)) / 100)
    if max(prim) > TIRED_THRESHOLD:
        score -= 3
    score -= 1.5 * used_patterns.get(ex["pattern"], 0)
    if ex["id"] in last_ids:
        score -= 1
    if ex["difficulty"] == level:
        score += 0.5
    return score + rng.random() * 0.8


def _working_candidates(exercises, equipment, level, chosen):
    return [e for e in exercises
            if is_available(e, equipment) and e["difficulty"] <= level
            and e["category"] != "mobility" and not is_long_cardio(e)
            and e["id"] not in chosen]


def _mobility_candidates(exercises, equipment, phase, chosen):
    roles = ("warmup", "both") if phase == "warmup" else ("cooldown", "both")
    return [e for e in exercises if e["category"] == "mobility"
            and e.get("role", "") in roles and is_available(e, equipment)
            and e["id"] not in chosen]


def generate_workout(exercises, hero, workouts, minutes, equipment, focus,
                     level=None, rng=None, when=None):
    """Build a structured, balanced, recovery-aware workout plan."""
    if focus not in SLOT_PLANS:
        raise ValidationError("Choose a workout focus.")
    if not 15 <= minutes <= 120:
        raise ValidationError("Workout length must be between 15 and 120 minutes.")
    rng = rng or random.Random()
    level = level or hero["training_level"]
    equipment = list(equipment)
    fatigue = fatigue_now(hero, when)
    last = workouts[-1] if workouts else None
    last_ids = {e.get("ex_id") for e in last.get("exercises", [])} if last else set()
    ex_map = {e["id"]: e for e in exercises}

    if not _working_candidates(exercises, equipment, level, set()):
        raise ValidationError("No exercises match the selected equipment and level.")

    chosen, used_patterns, notes = set(), {}, []
    warmups, mains, finishers, cooldowns = [], [], [], []

    # Warm-up (2) and cool-down (1-2) mobility work.
    for phase, count, bucket in (("warmup", 2, warmups),
                                 ("cooldown", 1 if minutes <= 30 else 2, cooldowns)):
        pool = _mobility_candidates(exercises, equipment, phase, chosen)
        rng.shuffle(pool)
        for ex in pool[:count]:
            chosen.add(ex["id"])
            bucket.append(prescribe(ex, "*", focus, level, hero, workouts, phase))

    # Core finisher is always included.
    core_pool = [e for e in _working_candidates(exercises, equipment, level, chosen)
                 if e["category"] == "core"]
    if core_pool:
        best = max(core_pool, key=lambda e: _score(e, "K", used_patterns, last_ids,
                                                   fatigue, level, rng))
        chosen.add(best["id"])
        finishers.append(prescribe(best, "K", focus, level, hero, workouts, "finisher"))

    fixed = sum(item_minutes(ex_map[i["ex_id"]], i) for i in warmups + cooldowns + finishers)
    budget = minutes - fixed

    # Pass 1: fill slots in priority order at 2 sets each, so short sessions
    # get more (balanced) exercises rather than fewer exercises with many sets.
    used_time, targets = 0.0, []
    for code, patterns in SLOT_PLANS[focus]:
        pool = [e for e in _working_candidates(exercises, equipment, level, chosen)
                if e["pattern"] in patterns]
        if code == "X":
            pool = [e for e in pool if e["category"] == "cardio"] or pool
        if not pool:
            continue
        best = max(pool, key=lambda e: _score(e, code, used_patterns, last_ids,
                                              fatigue, level, rng))
        item = prescribe(best, code, focus, level, hero, workouts, "main")
        target = item["sets"]
        item["sets"] = min(2, target)
        cost = item_minutes(best, item)
        if used_time + cost > budget and len(mains) >= 2:
            continue
        mains.append(item)
        targets.append(target)
        chosen.add(best["id"])
        used_patterns[best["pattern"]] = used_patterns.get(best["pattern"], 0) + 1
        used_time += cost

    # Pass 2: add sets back (highest-priority exercises first) while time allows.
    def grow_sets(used, caps):
        grew = True
        while grew:
            grew = False
            for item, cap in zip(mains, caps):
                if item["sets"] >= cap:
                    continue
                ex = ex_map[item["ex_id"]]
                before = item_minutes(ex, item)
                item["sets"] += 1
                delta = item_minutes(ex, item) - before
                if used + delta <= budget:
                    used += delta
                    grew = True
                else:
                    item["sets"] -= 1
        return used

    used_time = grow_sets(used_time, targets)
    # Small exercise pool for this equipment? Allow one bonus set each (max 5).
    if used_time < budget * 0.8:
        used_time = grow_sets(used_time, [min(5, t + 1) for t in targets])

    patterns_hit = {ex_map[i["ex_id"]]["pattern"] for i in mains + finishers}
    if focus not in ("Lower", "Conditioning") and "pull" not in patterns_hit:
        has_pull = any(e["pattern"] == "pull"
                       for e in _working_candidates(exercises, equipment, level, set()))
        notes.append("Not enough time for a pulling exercise - try a longer session."
                     if has_pull else
                     "No pulling exercise fits your equipment - a pull-up bar or bands helps.")
    items = warmups + mains + finishers + cooldowns
    est = sum(item_minutes(ex_map[i["ex_id"]], i) for i in items)
    return {"name": WORKOUT_NAMES.get(focus, "Quest"), "focus": focus,
            "level": level, "equipment": equipment, "items": items,
            "est_min": round(est), "notes": notes}


def plan_patterns(plan, ex_map):
    return {ex_map[i["ex_id"]]["pattern"] for i in plan["items"]
            if i["ex_id"] in ex_map} - {"mobility"}


def swap_item(plan, index, exercises, hero, workouts, rng=None):
    """Replace one plan item with another exercise of the same pattern."""
    rng = rng or random.Random()
    ex_map = {e["id"]: e for e in exercises}
    item = plan["items"][index]
    current = ex_map.get(item["ex_id"])
    if current is None:
        return False
    in_plan = {i["ex_id"] for i in plan["items"]}
    level, equipment = plan["level"], plan["equipment"]
    if item["phase"] in ("warmup", "cooldown"):
        pool = _mobility_candidates(exercises, equipment, item["phase"], in_plan)
    else:
        pool = [e for e in _working_candidates(exercises, equipment, level, in_plan)
                if e["pattern"] == current["pattern"]]
    if not pool:
        return False
    same_cat = [e for e in pool if e["category"] == current["category"]]
    pick = rng.choice(same_cat or pool)
    code = "C" if current["category"] == "compound" else "A"
    new_item = prescribe(pick, code, plan["focus"], level, hero, workouts, item["phase"])
    new_item["sets"] = max(1, min(new_item["sets"], item["sets"]))   # keep the time budget
    plan["items"][index] = new_item
    plan["est_min"] = plan_minutes(plan, ex_map)
    return True


def plan_minutes(plan, ex_map):
    return round(sum(item_minutes(ex_map[i["ex_id"]], i) for i in plan["items"]
                     if i["ex_id"] in ex_map))


def new_set(ex, reps=None, weight_lb=0.0, minutes=None):
    d = ex["default"]
    return {"target": reps if reps is not None else d.get("reps"),
            "reps": reps if reps is not None else d.get("reps"),
            "weight_lb": float(weight_lb or 0.0),
            "minutes": minutes if minutes is not None else d.get("minutes"),
            "effort": "moderate", "done": False}


def session_from_plan(plan, ex_map, when=None):
    items, planned = [], 0
    for it in plan["items"]:
        ex = ex_map.get(it["ex_id"])
        if ex is None:
            continue
        sets = [new_set(ex, it.get("reps"), it.get("weight_lb", 0.0), it.get("minutes"))
                for _ in range(it["sets"])]
        items.append({"ex_id": it["ex_id"], "rest": it["rest"],
                      "phase": it["phase"], "sets": sets})
        planned += len(sets)
    return {"name": plan["name"], "focus": plan["focus"],
            "started": iso(when or now()), "items": items, "planned_sets": planned}


def empty_session(when=None):
    return {"name": WORKOUT_NAMES["Custom"], "focus": "Custom",
            "started": iso(when or now()), "items": [], "planned_sets": 0}


# =====================================================================
#  FINISH A WORKOUT  (XP, stats, PRs, boss, quests, achievements)
# =====================================================================

def finish_workout(hero, workouts, ex_map, session, when=None):
    """Score a session, update the hero, append to history. Returns a summary."""
    when = when or now()
    done_total = sum(1 for it in session["items"] for s in it["sets"] if s.get("done"))
    if done_total == 0:
        raise ValidationError("Complete at least one set before finishing the workout.")

    started = parse_iso(session.get("started"), when)
    duration = max(1, min(240, int(round((when - started).total_seconds() / 60))))
    level_before = level_info(hero["total_xp"])[0]
    class_before = hero_class(hero)[0]
    ensure_week(hero, when)
    decay_fatigue(hero, when)
    pre_fatigue = dict(hero["fatigue"])
    bodyweight = hero["bodyweight_lb"]

    base_xp, stat_gain, prs, tired_sets = 0.0, {s: 0.0 for s in STATS}, [], 0
    patterns, exercises_log, lines = set(), [], []
    for it in session["items"]:
        ex = ex_map.get(it["ex_id"])
        done_sets = [s for s in it["sets"] if s.get("done")]
        if ex is None or not done_sets:
            continue
        tired = any(pre_fatigue.get(m, 0) > TIRED_THRESHOLD for m in ex["primary"])
        ex_xp = 0.0
        for s in done_sets:
            xp = set_xp(ex, s, bodyweight)
            if tired:
                xp *= TIRED_PENALTY
                tired_sets += 1
            ex_xp += xp
            apply_set_fatigue(hero, ex, s)
        # Personal record check (best set of this exercise today).
        def rank(st):
            t, v, _d = record_of(ex, st)
            return RECORD_TYPES[t], v
        best = max(done_sets, key=rank)
        rtype, value, shown = record_of(ex, best, hero["units"])
        old = hero["records"].get(ex["id"])
        old_rank = RECORD_TYPES.get(old.get("type"), -1) if old else -1
        same_type_better = old is not None and old.get("type") == rtype and value > old.get("value", 0)
        if same_type_better:
            prs.append(ex["name"])
        if old is None or RECORD_TYPES[rtype] > old_rank or same_type_better:
            hero["records"][ex["id"]] = {"type": rtype, "value": value, "display": shown,
                                         "date": iso(when), "name": ex["name"],
                                         "weight_lb": float(best.get("weight_lb") or 0),
                                         "reps": int(best.get("reps") or 0),
                                         "minutes": float(best.get("minutes") or 0)}
        base_xp += ex_xp
        stat_gain[ex["stat"]] += ex_xp
        if ex["pattern"] != "mobility":
            patterns.add(ex["pattern"])
        lines.append((ex["name"], len(done_sets), round(ex_xp)))
        exercises_log.append({
            "ex_id": ex["id"], "name": ex["name"], "pattern": ex["pattern"],
            "category": ex["category"], "kind": ex["kind"],
            "per_hand": ex.get("per_hand", False), "xp": round(ex_xp, 1),
            "sets": [{k: s.get(k) for k in ("target", "reps", "weight_lb", "minutes", "effort")}
                     for s in done_sets]})

    planned = session.get("planned_sets", 0)
    if session.get("focus") == "Custom":
        planned_done = done_total
    else:
        planned_done = sum(1 for it in session["items"] if it.get("phase") != "extra"
                           for s in it["sets"] if s.get("done"))
    complete = planned > 0 and planned_done >= planned
    balanced = len(patterns) >= 3
    streak = current_streak(workouts + [{"date": iso(when)}], when)
    bonus_pct = (0.10 if complete else 0) + (0.10 if balanced else 0)
    streak_mult = 1 + 0.05 * min(streak, 5)
    workout_xp = int(round(base_xp * (1 + bonus_pct) * streak_mult + PR_BONUS * len(prs)))

    workouts.append({
        "id": when.strftime("w%Y%m%d%H%M%S"), "date": iso(when),
        "name": session["name"], "focus": session["focus"],
        "duration_min": duration, "sets_done": done_total,
        "exercises": exercises_log, "xp": workout_xp, "prs": prs})
    for s in STATS:
        hero["stat_xp"][s] = round(hero["stat_xp"][s] + stat_gain[s], 1)
    hero["prs_broken"] += len(prs)
    hero["best_streak"] = max(hero["best_streak"], streak)

    # Weekly boss takes damage equal to the workout XP.
    boss = hero["boss"]
    boss_bonus, boss_defeated, damage = 0, False, 0
    if not boss["defeated"]:
        damage = min(boss["hp"], workout_xp)
        boss["hp"] -= damage
        if boss["hp"] <= 0:
            boss.update(hp=0, defeated=True, defeated_on=iso(when))
            hero["bosses_defeated"] += 1
            title = f"Slayer of {boss['name']}"
            if title not in hero["titles"]:
                hero["titles"].append(title)
            boss_bonus, boss_defeated = BOSS_BONUS, True

    # Quests.
    quest_bonus, quests_done = 0, []
    wk = week_workouts(workouts, when)
    for q in hero["quests"]["list"]:
        if not q["done"] and quest_progress(q, wk) >= q["n"]:
            q["done"] = True
            quest_bonus += q["reward"]
            quests_done.append(quest_text(q))

    gained = workout_xp + boss_bonus + quest_bonus
    hero["total_xp"] += gained
    level_after = level_info(hero["total_xp"])[0]
    achievements = check_achievements(hero, workouts, when)
    hero["active_session"] = None

    return {
        "workout_xp": workout_xp, "base_xp": round(base_xp), "total_gained": gained,
        "complete": complete, "balanced": balanced, "streak": streak,
        "streak_mult": streak_mult, "prs": prs, "tired_sets": tired_sets,
        "lines": lines, "stat_gain": {s: round(v) for s, v in stat_gain.items()},
        "boss_damage": damage, "boss_defeated": boss_defeated, "boss_bonus": boss_bonus,
        "quests_done": quests_done, "quest_bonus": quest_bonus,
        "level_before": level_before, "level_after": level_after,
        "class_before": class_before, "class_after": hero_class(hero)[0],
        "achievements": achievements, "duration": duration, "sets": done_total,
    }


def weekly_xp(workouts, weeks=8, when=None):
    """[(week start date, xp)] for the last `weeks` weeks, oldest first."""
    when = when or now()
    this_monday = (when - dt.timedelta(days=when.weekday())).date()
    out = []
    for k in range(weeks - 1, -1, -1):
        start = this_monday - dt.timedelta(weeks=k)
        end = start + dt.timedelta(days=7)
        total = sum(int(w.get("xp", 0)) for w in workouts
                    if start <= parse_iso(w["date"]).date() < end)
        out.append((start, total))
    return out


def fmt_date(when, with_time=True):
    text = f"{when:%a, %b} {when.day}"
    if with_time:
        text += " · " + when.strftime("%I:%M %p").lstrip("0")
    return text


def guide_text(ex):
    """(full how-to text, source credit) for the phone's guide sheet."""
    text = (ex.get("how_to") or "").strip()
    if not text:
        text = ("No description yet for this custom exercise." if ex.get("custom")
                else NO_GUIDE)
        return text, ""
    return text, ex.get("how_to_source", "")


def clean_session(session, ex_map):
    """Drop anything in a restored session that no longer makes sense."""
    if not isinstance(session, dict) or not isinstance(session.get("items"), list):
        return None
    items = [it for it in session["items"] if isinstance(it, dict) and it.get("ex_id") in ex_map
             and isinstance(it.get("sets"), list)]
    session["items"] = items
    session.setdefault("name", WORKOUT_NAMES["Custom"])
    session.setdefault("focus", "Custom")
    session.setdefault("planned_sets", 0)
    if parse_iso(session.get("started")) is None:
        session["started"] = iso(now())
    return session


# =====================================================================
#  CUSTOM EXERCISES  (same rules as the desktop Library page's form)
# =====================================================================

def custom_exercise(exercises, form, editing_id=None, when=None):
    """Validate a custom-exercise form and build the exercise.

    form keys: name, description, pattern, category, primary, secondary
    ("none" or a muscle), kind ("reps"/"timed"), sets, amount (text),
    difficulty (1-3), stat, equipment (list), per_hand (bool).
    Returns (exercise, errors) - errors maps a form key to its message and
    the exercise is None whenever errors is not empty. When editing_id is
    given, that exercise keeps its id and may keep its own name.
    """
    errors = {}
    name = ""
    try:
        name = validate_name(form.get("name", ""), EXERCISE_NAME_MAX, "Exercise name")
        if any(e["name"].lower() == name.lower() and e["id"] != editing_id for e in exercises):
            raise ValidationError(f"'{name}' is already in the library.")
    except ValidationError as err:
        errors["name"] = str(err)
    try:
        sets = parse_int(str(form.get("sets", "")).strip() or "3", 1, 10, "Sets")
    except ValidationError as err:
        errors["sets"] = str(err)
    kind = form.get("kind", "reps")
    if kind not in ("reps", "timed"):
        errors["kind"] = "Choose how the exercise is logged."
    try:
        raw = str(form.get("amount", "")).strip()
        if kind == "timed":
            amount = parse_float(raw or "1", *MINUTES_RANGE, "Minutes")
        else:
            amount = parse_int(raw or "10", *REPS_RANGE, "Reps")
    except ValidationError as err:
        errors["amount"] = str(err)
    try:
        desc = validate_description(form.get("description", ""))
    except ValidationError as err:
        errors["description"] = str(err)
    pattern, category = form.get("pattern"), form.get("category")
    prim, sec = form.get("primary"), form.get("secondary") or "none"
    if pattern not in PATTERNS:
        errors["pattern"] = "Choose a movement pattern."
    if category not in CATEGORIES:
        errors["category"] = "Choose a category."
    if prim not in MUSCLES:
        errors["primary"] = "Choose a primary muscle."
    if sec != "none" and sec not in MUSCLES:
        errors["secondary"] = "Choose a secondary muscle."
    elif sec == prim:
        errors["secondary"] = "Secondary muscle must be different from the primary muscle."
    difficulty = form.get("difficulty", 1)
    if difficulty not in DIFF_MULT:
        errors["difficulty"] = "Choose a difficulty."
    stat = form.get("stat", "STR")
    if stat not in STATS:
        errors["stat"] = "Choose a stat."
    if errors:
        return None, errors
    equip = [e for e in EQUIPMENT if e in form.get("equipment", [])]
    per_hand = bool(form.get("per_hand")) and kind == "reps" and "dumbbells" in equip
    if editing_id:
        ex_id = editing_id
    else:
        slug = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")
        ex_id = f"custom_{slug}_{(when or now()):%H%M%S}"
        taken = {e["id"] for e in exercises}
        n = 2
        while ex_id in taken:
            ex_id = f"custom_{slug}_{(when or now()):%H%M%S}_{n}"
            n += 1
    ex = _ex(ex_id, name, pattern, category, [prim], [] if sec == "none" else [sec],
             equip, difficulty, stat, kind, 0.0, sets, amount, 0.0, per_hand,
             "both" if category == "mobility" else "")
    ex["custom"] = True
    ex["how_to"] = desc
    ex["how_to_source"] = CUSTOM_SOURCE if desc else ""
    return ex, {}


def check_not_in_session(ex, session):
    """Custom exercises can't be changed or deleted while in the current workout."""
    if session and any(it.get("ex_id") == ex["id"] for it in session.get("items", [])):
        raise ValidationError(f"{ex['name']} is in your current workout. "
                              "Finish or discard it first.")


def save_custom_exercise(exercises, ex):
    """Add a new custom exercise, or replace the one with the same id."""
    for i, old in enumerate(exercises):
        if old["id"] == ex["id"]:
            exercises[i] = ex
            return
    exercises.append(ex)


def delete_custom_exercise(exercises, ex_id, session=None, plan=None):
    """Remove a custom exercise. Past workouts keep their history.
    Returns the plan (or None if the plan became empty)."""
    ex = next((e for e in exercises if e["id"] == ex_id), None)
    if ex is None or not ex.get("custom"):
        raise ValidationError("Only your own custom exercises can be deleted.")
    check_not_in_session(ex, session)
    exercises[:] = [e for e in exercises if e["id"] != ex_id]
    if plan:
        plan["items"] = [i for i in plan["items"] if i["ex_id"] != ex_id]
        if not plan["items"]:
            return None
        plan["est_min"] = plan_minutes(plan, {e["id"]: e for e in exercises})
    return plan


def filter_library(exercises, query="", pattern="all", equipment="all", mine=()):
    """Search/filter the library like the desktop Library page.
    equipment: 'all', 'mine', 'bodyweight', or one equipment name."""
    q = query.strip().lower()
    out = []
    for e in exercises:
        if q and q not in e["name"].lower() and not any(q in m for m in e["primary"] + e["secondary"]):
            continue
        if pattern != "all" and e["pattern"] != pattern:
            continue
        if equipment == "mine" and not set(e["equipment"]) <= set(mine):
            continue
        if equipment == "bodyweight" and e["equipment"]:
            continue
        if equipment in EQUIPMENT and equipment not in e["equipment"]:
            continue
        out.append(e)
    # Custom exercises first so they're easy to find.
    return sorted(out, key=lambda e: (not e.get("custom"), PATTERNS.index(e["pattern"]), e["name"]))
